<!DOCTYPE html>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'nav.php';
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>piggybank | Categories</title>
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/exploretags.css">
    <link rel="stylesheet" href="../css/makePost.css">
    <script src="../js/recent.js"></script>
    <script src="../js/makePost.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>
<body>
    <header>
        <img id="header_icon" src="../SVG/piggybank_w (logo).svg" alt="piggybank logo">
        <div id="searchbar">
            <label for="search"><img id="search_icon" src="../SVG/search-icon_w.svg" alt="search icon"></label>
            <input id="search" type="text" placeholder="Search">
        </div>
    </header>
    
    <!-- <div class="container"> -->
    <div class="main-body">
        <nav>
            <div>
                <button class="nav-btn active" onclick="location.href='exploretags.php'">Categories</button>
                <button class="nav-btn" onclick="location.href='./recent.php'">Recent</button>
                <button class="nav-btn" onclick="location.href='./trending.html'">Trending</button>
                <!-- <button class="nav-btn" onclick="makePost()">Make post</button> -->
                 <?php makePost();?>
            </div>
            <!-- <div style="justify-content: end;">
                <button class="nav-btn" id="logout-btn" style="display: block;">Log Out</button>
                <button class="nav-btn" onclick="location.href='settings.html'">
                    <span>Settings</span>
                    <img id="pfp" class="pfp" src="SVG/settings_icon.svg" alt="settings icon">
                </button>
                <button class="nav-btn" onclick="location.href='viewAccount.html'">
                    <span>View Account</span>
                    <img id="pfp" class="pfp" src="icons8-male-user-100.png" alt="profile picture">
                </button>
            </div> -->
            <?php viewAccount();?>
        </nav>

        <main>
            <div class="tag-container">
                <!-- <button class="tag" style="color: red;">#movie</button>
                <button class="tag" style="color: blue;">#book</button>
                <button class="tag" style="color: purple;">#marvel</button>
                <button class="tag" style="color: green;">#technology</button>
                <button class="tag" style="color: brown;">#coffee</button>
                <button class="tag" style="color: rgb(134, 89, 6);">#harrypotter</button>
                <button class="tag" style="color: teal;">#exercise</button>
                <button class="tag" style="color: rgb(174, 45, 67);">#design</button>
                <button class="tag" style="color: rgb(33, 129, 129);">#food</button>
                <button class="tag" style="color: darkblue;">#dayinmylife</button>
                <button class="tag" style="color: darkred;">#fashion</button> -->
                <button class="tag" style="background-color: rgb(255, 180, 180, 0.3);">movie</button>
                <button class="tag" style="background-color: rgba(200, 255, 180, 0.3);">book</button>
                <button class="tag" style="background-color: rgba(180, 201, 255, 0.3);">marvel</button>
                <button class="tag" style="background-color: rgba(249, 180, 255, 0.3);">technology</button>
                <button class="tag" style="background-color: rgba(255, 254, 180, 0.3);">coffee</button>
                <button class="tag" style="background-color: rgba(185, 180, 255, 0.3);">harrypotter</button>
                <button class="tag" style="background-color: rgba(180, 255, 238, 0.3);">exercise</button>
                <button class="tag" style="background-color: rgba(255, 180, 193, 0.3);">design</button>
                <button class="tag" style="background-color: rgba(211, 255, 180, 0.3);">food</button>
                <button class="tag" style="background-color: rgba(255, 225, 180, 0.3);">dayinmylife</button>
                <button class="tag" style="background-color: rgba(230, 180, 255, 0.3);">fashion</button>
            </div>
        </main>
    </div>

    <!-- Modal -->
    <div id="loginModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <p>User must be logged in to create posts.</p>
        </div>
    </div>
<!-- 
    <script src="../js/exploretags.js"></script> -->
</body>
</html>