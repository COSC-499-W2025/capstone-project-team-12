
<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="../css/reset.css">
 <link rel="stylesheet" href="../css/main.css">
 <link rel="stylesheet" href="../css/makePost.css">
 <title>Make Post</title>
</head>
<body>
 <div id='post-expand-container'>
    <div class='overlay'></div>
    <div class='makePost-container'>
            <button id='closeMakePost' onclick='window.history.back()'></button>
                <form id='blogpostForm' method='post' action='newPost.php' style="background-color: white; color: black;">
                    <input type='text' id='makePostTitle' name='title' placeholder='Title'><br>
                <textarea id='makePostBody' name='body' placeholder='Body' maxlength='2500' rows='13'></textarea>
                <div id='makePostFunctions'>
                    <div id='makePostExtras'>
                        <div id='imgAttachmentsContainer'>
                            <div id='imgAttachmentsWrapper' style='margin-inline-end:5px;'>
                                <!-- <div class='imgAttachment'>
                                    <label class='addImageLabel' for='image0'>Add Image</label>
                                    <input type='file' id='image0' name='images[]' accept='image/*' style='display:none;' onchange='updateImgLabel(this.id);'>
                                    <button type='button' class='rmFileBtn' onclick='rmFile(`image0`);'>
                                        <img src='../SVG/icons8-close_w.svg' >
                                    </button>
                                </div> -->
                            </div>
                            <button type='button' id='addMoreBtn' onclick='addMore()'>add more</button>
                        </div>
                        <div class='separator'></div>
                        <div id='catSelectContainer'>
                            <select id='categoriesSelect' name='category'>
                                <option value="" selected>Choose Category</option>
                                <option value='movies'>Movies</option>
                                <option value='tech'>Technology</option>
                                <option value='food'>Food</option>
                                <option value='health'>Health</option>
                                <option value='fashion'>Fashion</option>
                            </select>
                        </div>
                     <script src="../js/newMakePost.js"></script>
                    </body>
                    </html>
                    <div style='display:flex;'>
                        <button type='button' id='draftBtn' onclick='draftPost();'>Draft</button>
                        <button type='submit' id='postBtn' onclick='uploadPost(event);'>Post</button>  
                    
                </div>
            
        


                </div>
            </form>
    </div>
</div>