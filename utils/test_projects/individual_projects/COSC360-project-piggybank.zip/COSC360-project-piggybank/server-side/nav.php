<?php 

// session_start();
// $isLoggedIn = isset($_SESSION['user']);
$isLoggedIn = true;
$isAdmin = true;


function makePost(){
    global $isLoggedIn;
    if($isLoggedIn){
        echo '<button class="nav-btn" onclick="location.href=`../server-side/newMakePost.php`">Make post</button>';
    }
}

function viewAccount(){
    global $isLoggedIn;
    if($isLoggedIn){
        echo "
            <div class='logged-in-nav'style='justify-content: end;'>
                <button class='nav-btn' id='logout-btn'>Log Out</button>
                <button class='nav-btn' onclick='location.href=`../settings.html`'>
                    <span>Settings</span>
                    <img id='pfp' class='pfp' src='../SVG/settings_icon.svg' alt='settings icon'>
                </button>
                <button class='nav-btn' onclick='location.href=`../viewAccount.html`'>
                    <span>View Account</span>
                    <img id='pfp' class='pfp' src='../SVG/icons8-male-user-100.png' alt='profile picture'>
                </button>
            </div>
            ";
    }else{
        echo "
            <div style='justify-content: end;'>
                <button class='nav-btn' id='login-btn' onclick='location.href = `../loginpage.html`;'>Login</button>
            </div>
            ";
    }
}

?>