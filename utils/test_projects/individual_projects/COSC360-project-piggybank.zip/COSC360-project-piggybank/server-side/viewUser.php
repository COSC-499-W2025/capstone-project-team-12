<?php 
include 'server-side/nav.php';

// Get username from URL parameter
$username = isset($_GET['username']) ? $_GET['username'] : '';

if (empty($username)) {
    // Redirect or show error if no username provided
    echo "<script>alert('No user specified'); window.location.href='recent.html';</script>";
    exit;
}

// Get user information from database
include 'server-side/db_connect.php'; // Your database connection file

$stmt = $pdo->prepare("SELECT username, profile_pic, bio, full_name FROM users WHERE username = ?");
$stmt->execute([$username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    // User not found
    echo "<script>alert('User not found'); window.location.href='recent.html';</script>";
    exit;
}

// Get post count only
$stmt = $pdo->prepare("SELECT COUNT(*) as post_count FROM blogs WHERE username = ?");
$stmt->execute([$username]);
$postCount = $stmt->fetch(PDO::FETCH_ASSOC)['post_count'];

// Get user's posts in JSON format for JavaScript
$stmt = $pdo->prepare("SELECT pfp, username, content, tag, id FROM blogs WHERE username = ? ORDER BY created_at DESC");
$stmt->execute([$username]);
$posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
$postsJson = json_encode($posts);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>piggybank | <?php echo htmlspecialchars($user['username']); ?></title>
    <link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/viewPosts.css">
    <link rel="stylesheet" href="css/viewAccount.css">
    <link rel="stylesheet" href="css/viewAccountPosts.css">
    <link rel="stylesheet" href="css/blogpostExpand.css">
</head>
<body>
    <header>
        <img id="header_icon" src="./SVG/piggybank_w (logo).svg" alt="piggybank logo">
        <div id="searchbar">
            <label for="search" style="display: inherit;"><img id="search_icon" src="./SVG/search-icon_w.svg" alt="search icon"></label>
            <input id="search" type="search" placeholder="Search">
        </div>
    </header>
    <div class="main-body">
        <nav>
            <div>
                <button class="nav-btn" onclick="location.href='server-side/exploretags.php'">Categories</button>
                <button class="nav-btn" onclick="location.href='recent.html'">Recent</button>
                <button class="nav-btn" onclick="location.href='trending.html'">Trending</button>
                <?php makePost(); ?>
            </div>
            <div style="justify-content: end;">
                <button class="nav-btn" id="logout-btn" style="display: block;">Log Out</button>
                <button class="nav-btn" onclick="location.href='settings.html'">
                    <span>Settings</span>
                    <img id="pfp" class="pfp" src="SVG/settings_icon.svg" alt="settings icon">
                </button>
                <?php viewAccount(); ?>
            </div>
        </nav>
        <main>
            <div id="account-info">
                <div id="account-info-top">
                    <div>
                        <img id="account-pfp" src="<?php echo htmlspecialchars($user['profile_pic']); ?>" alt="profile picture">
                    </div>
                    <div>
                        <h1 id="account-username"><?php echo htmlspecialchars($user['username']); ?></h1>
                        <h2><?php echo htmlspecialchars($user['bio']); ?></h2>
                        <p><?php echo htmlspecialchars($user['full_name']); ?></p>
                        <p><?php echo $postCount;