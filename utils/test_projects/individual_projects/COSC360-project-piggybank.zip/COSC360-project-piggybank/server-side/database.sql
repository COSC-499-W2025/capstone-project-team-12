CREATE DATABASE piggybank;

USE piggybank;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL
);

-- Insert a dummy user for login
INSERT INTO users (first_name, last_name, email, username, password) 
VALUES ('Jane', 'Smith', 'janesmith@email.com', 'janesmith1', 'Smith123');
