<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "You are not logged in.";
    exit;
}

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "piggybank";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['username'])) {
    $username = $_POST['username'];

    // Sanitize the username
    $username = htmlspecialchars($username);

    $user_id = $_SESSION['user_id'];

    // Prepare and bind
    $stmt = $conn->prepare("UPDATE users SET username = ? WHERE id = ?");
    $stmt->bind_param("si", $username, $user_id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Username updated successfully";
    } else {
        echo "Error updating username: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
} elseif (isset($_POST['email'])) {
    $email = $_POST['email'];

    // Sanitize the email
    $email = htmlspecialchars($email);

    $user_id = $_SESSION['user_id'];

    // Prepare and bind
    $stmt = $conn->prepare("UPDATE users SET email = ? WHERE id = ?");
    $stmt->bind_param("si", $email, $user_id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Email updated successfully";
    } else {
        echo "Error updating email: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
} elseif (isset($_POST['name'])) {
    $name = $_POST['name'];

    // Sanitize the name
    $name = htmlspecialchars($name);

    $user_id = $_SESSION['user_id'];

    // Prepare and bind
    $stmt = $conn->prepare("UPDATE users SET name = ? WHERE id = ?");
    $stmt->bind_param("si", $name, $user_id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Name updated successfully";
    } else {
        echo "Error updating name: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
} elseif (isset($_POST['currentPassword']) && isset($_POST['newPassword']) && isset($_POST['confirmPassword'])) {
    $currentPassword = $_POST['currentPassword'];
    $newPassword = $_POST['newPassword'];
    $confirmPassword = $_POST['confirmPassword'];

    $user_id = $_SESSION['user_id'];

    // Fetch the user's current password from the database
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->bind_result($hashedPassword);
    $stmt->fetch();
    $stmt->close();

    // Verify the current password
    if (!password_verify($currentPassword, $hashedPassword)) {
        echo "Incorrect current password.";
        exit;
    }

    // Check if the new password and confirm password match
    if ($newPassword !== $confirmPassword) {
        echo "New passwords do not match!";
        exit;
    }

    // Hash the new password
    $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    // Update the password in the database
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $hashedNewPassword, $user_id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Password updated successfully";
    } else {
        echo "Error updating password: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
} else {
    echo "No username, email, name, or password data provided.";
}

// Close the connection
$conn->close();
?>