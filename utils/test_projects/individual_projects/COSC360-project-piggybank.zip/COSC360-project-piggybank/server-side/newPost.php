<?php
session_start();

$servername = "localhost";
$username = "piggybank";
$password = "blog";
$dbname = "piggybank";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    $title = $_POST['title'];
    $content = $_POST['body'];
    $category = $_POST['category'];

    $stmt = $conn->prepare("INSERT INTO posts (user_id, title, content, tag) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $userId, $title, $content, $category);

    if ($stmt->execute()) {
        echo "New post created successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "User not logged in";
}

$conn->close();

?>