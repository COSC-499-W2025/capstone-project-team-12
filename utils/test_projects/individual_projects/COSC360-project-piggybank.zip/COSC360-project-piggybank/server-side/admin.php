<?php
// Database connection details
$host = "localhost";
$username = "root";
$password = "";
$database = "piggybank";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get search parameters from request
$searchBy = $_GET["search-by"];
$searchTerm = $_GET["search-term"];

// Prepare the SQL query based on the search criteria
$sql = "";
if ($searchBy == "name") {
  $sql = "SELECT users.id, users.username, users.email, COUNT(posts.post_id) AS post_count
          FROM users
          LEFT JOIN posts ON users.id = posts.user_id
          WHERE users.username LIKE '%$searchTerm%'
          GROUP BY users.id";
} elseif ($searchBy == "email") {
  $sql = "SELECT users.id, users.username, users.email, COUNT(posts.post_id) AS post_count
          FROM users
          LEFT JOIN posts ON users.id = posts.user_id
          WHERE users.email LIKE '%$searchTerm%'
          GROUP BY users.id";
} elseif ($searchBy == "post") {
  $sql = "SELECT DISTINCT users.id, users.username, users.email, COUNT(posts.post_id) AS post_count
          FROM users
          INNER JOIN posts ON users.id = posts.user_id
          WHERE posts.post_id = '$searchTerm'
          GROUP BY users.id";
} elseif ($searchBy == "post_id") {
  $sql = "SELECT DISTINCT users.id, users.username, users.email, COUNT(posts.post_id) AS post_count
          FROM users
          INNER JOIN posts ON users.id = posts.user_id
          WHERE posts.post_id = '$searchTerm'
          GROUP BY users.id";
}

// Execute query
$result = $conn->query($sql);

// Prepare the response
$response = array();
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    $response[] = $row;
  }
} else {
  $response["message"] = "No users found matching your search criteria.";
}


header('Content-Type: application/json');
echo json_encode($response);


// Handle stats request
if (isset($_GET['stats'])) {
    $statsType = $_GET['stats'];
    $count = 0;

    if ($statsType === 'users') {
        $countQuery = "SELECT COUNT(*) AS count FROM users";
    } elseif ($statsType === 'posts') {
        $countQuery = "SELECT COUNT(*) AS count FROM posts";
    } else {
        header('Content-Type: application/json');
        echo json_encode(['message' => 'Invalid stats type.']);
        $conn->close();
        exit;
    }

    $countResult = $conn->query($countQuery);

    if ($countResult) {
        $countData = $countResult->fetch_assoc();
        $count = $countData['count'];

        header('Content-Type: application/json');
        echo json_encode(['count' => $count]);
    } else {
        header('Content-Type: application/json');
        echo json_encode(['message' => 'Error fetching stats.']);
    }

    $conn->close();
    exit;
}


$conn->close();
?>