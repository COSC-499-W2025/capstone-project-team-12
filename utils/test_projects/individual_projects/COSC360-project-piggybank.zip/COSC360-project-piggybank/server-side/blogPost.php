<?php
if(isset($_GET['blogId'])) {
    $id = $_GET['blogId'];
    //TODO: go to DB to retrieve data about the blog of that ID
}
?>
<!DOCTYPE html>
<?php include 'nav.php'?>
<html>
<head>
    <title>piggybank | Recent</title>
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/recent.css">
    <link rel="stylesheet" href="../css/blogpostExpand.css">
    <link rel="stylesheet" href="../css/makePost.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>
<body>
    <header>
        <img id="header_icon" src="../SVG/piggybank_w (logo).svg" alt="piggybank logo">
        <div id="searchbar">
            <label for="search" style="display: inherit;"><img id="search_icon" src="../SVG/search-icon_w.svg" alt="search icon"></label>
            <input id="search" type="search" placeholder="Search">
        </div>  
    </header>
    <div class="main-body">
        <nav>
            <div>
                <button class="nav-btn" onclick="location.href='server-side/exploretags.php'">Categories</button>
                <button class="nav-btn active" onclick="location.href='recent.php'">Recent</button>
                <button class="nav-btn" onclick="location.href='../trending.html'">Trending</button>
                 <?php makePost();?>
            </div>
            <?php viewAccount();?>
        </nav>
        <main>
        </main>
    </div>      
    <script src="../js/recent.js"></script>
    <script src='../js/makePost.js'></script>
    
</body>

</html>