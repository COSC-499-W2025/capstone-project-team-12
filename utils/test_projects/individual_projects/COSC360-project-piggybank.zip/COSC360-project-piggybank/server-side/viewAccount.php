<?php
session_start(); // Make sure to start the session


$servername = "localhost"; // Local environment
$username = "piggybank";
$password = "blog";
$dbname = "piggybank";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
   header('Content-Type: application/json');
   http_response_code(500);
   echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
   exit();
}


try {
   // Determine which user_id to use for filtering posts
   $userId = null;
  
   // Check if username parameter is provided (for viewing other users)
   if (isset($_GET['username']) && !empty($_GET['username'])) {
       $usernameParam = $_GET['username'];
       $userIdStmt = $conn->prepare("SELECT user_id FROM users WHERE username = ?");
       $userIdStmt->bind_param("s", $usernameParam);
       $userIdStmt->execute();
       $userIdResult = $userIdStmt->get_result();
      
       if ($userIdResult->num_rows > 0) {
           $userId = $userIdResult->fetch_assoc()['user_id'];
       }
       $userIdStmt->close();
   }
   // Otherwise use the logged-in user's ID from session (for viewing own account)
   else if (isset($_SESSION['user_id'])) {
       $userId = $_SESSION['user_id'];
   }
  
   // Get posts - either all or filtered by user_id
   if ($userId !== null) {
       // Get posts for specific user
       $stmt = $conn->prepare("SELECT post_id, user_id, title, content, tag, image_url, created_at FROM posts WHERE user_id = ? ORDER BY created_at DESC");
       $stmt->bind_param("i", $userId);
   } else {
       // Get all posts if no user filtering is applied
       $stmt = $conn->prepare("SELECT post_id, user_id, title, content, tag, image_url, created_at FROM posts ORDER BY created_at DESC");
   }
  
   $stmt->execute();
   $result = $stmt->get_result();
  
   $blogs = array();
  
   // while there are rows in the result (i.e. while there are posts)
   while($row = $result->fetch_assoc()) {
       // Prepare user statement
       $userStmt = $conn->prepare("SELECT username, profile_pic FROM users WHERE user_id = ?");
       $userStmt->bind_param("i", $row["user_id"]);
       $userStmt->execute();
       $userResult = $userStmt->get_result();
       $userInfo = $userResult->fetch_assoc();
      
       $blog = array(
           "pfp" => isset($userInfo["profile_pic"]) ? $userInfo["profile_pic"] : "SVG/icons8-male-user-100.png",
           "username" => isset($userInfo["username"]) ? $userInfo["username"] : "Anonymous",
           "content" => array(
               "blogHead" => isset($row["title"]) ? $row["title"] : "",
               "blogBody" => isset($row["content"]) ? $row["content"] : "",
               "images" => isset($row["image_url"]) ? $row["image_url"] : ""
           ),
           "tag" => isset($row["tag"]) ? $row["tag"] : "",
           "id" => $row["post_id"]
       );
      
       $blogs[] = $blog;
      
       $userStmt->close();
   }
  
   $stmt->close();
  
   header('Content-Type: application/json');
   echo json_encode($blogs);
  
} catch(Exception $e) {
   header('Content-Type: application/json');
   http_response_code(500);
   echo json_encode(["error" => "Database error: " . $e->getMessage()]);
} finally {
   $conn->close();
}
?>
