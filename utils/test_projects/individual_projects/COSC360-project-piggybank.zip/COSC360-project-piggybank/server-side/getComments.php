<?php
session_start(); // Start the session

// Database connection details
$host = "localhost";
$username = "root";
$password = "";
$database = "piggybank";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get the logged-in user's ID from the session
if (isset($_SESSION["user_id"])) {
  $loggedInUserId = $_SESSION["user_id"];

  // SQL query to fetch comments on the logged-in user's posts along with the commenter's username
  $sql = "SELECT comments.comment_text, comments.comment_id, posts.post_id, users.username
          FROM comments
          INNER JOIN posts ON comments.post_id = posts.post_id
          INNER JOIN users ON comments.user_id = users.id
          WHERE posts.user_id = $loggedInUserId";

  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    // Fetch all comments into an array
    $comments = array();
    while($row = $result->fetch_assoc()) {
      $comments[] = $row;
    }

    // Encode the array as JSON
    $json_response = json_encode($comments);

    // Set the content type to JSON
    header('Content-Type: application/json');

    // Output the JSON data
    echo $json_response;
  } else {
    echo json_encode(array("message" => "No comments found on your posts."));
  }
} else {
  echo json_encode(array("message" => "User not logged in."));
}

// Close the connection
$conn->close();
?>