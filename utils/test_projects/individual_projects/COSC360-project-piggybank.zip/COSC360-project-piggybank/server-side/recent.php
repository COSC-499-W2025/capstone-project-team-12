<!DOCTYPE html>
<?php include 'nav.php';?>
<html>
<head>
    <title>piggybank | Recent</title>
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/recent.css">
    <link rel="stylesheet" href="../css/blogpostExpand.css">
    <link rel="stylesheet" href="../css/makePost.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
</head>
<body>
    <header>
        <img id="header_icon" src="../SVG/piggybank_w (logo).svg" alt="piggybank logo">
        <div id="searchbar">
            <label for="search" style="display: inherit;"><img id="search_icon" src="../SVG/search-icon_w.svg" alt="search icon"></label>
            <input id="search" type="search" placeholder="Search">
        </div>  
    </header>
    <div class="main-body">
        <nav>
            <div>
                <button class="nav-btn" onclick="location.href='exploretags.php'">Categories</button>
                <button class="nav-btn active" onclick="location.href='recent.php'">Recent</button>
                <button class="nav-btn" onclick="location.href='../trending.html'">Trending</button>
                <!-- <button class="nav-btn" onclick="makePost()">Make post</button> -->
                 <?php makePost();?>
            </div>
            <!-- <div style="justify-content: end;">
                <button class="nav-btn" id="logout-btn" style="display: block;">Log Out</button>
                <button class="nav-btn" onclick="location.href='settings.html'">
                    <span>Settings</span>
                    <img id="pfp" class="pfp" src="SVG/settings_icon.svg" alt="settings icon">
                </button>
                <button class="nav-btn" onclick="location.href='viewAccount.html'">
                    <span>View Account</span>
                    <img id="pfp" class="pfp" src="icons8-male-user-100.png" alt="profile picture">
                </button>
            </div> -->
            <?php viewAccount();?>
        </nav>
        <main>
            <div class="grid-column">
                <!-- <div class="blogpost">
                    <div class="post-account">
                        <img class="pfp" src="icons8-male-user-100.png">
                        <span>piggyuser1000</span>
                    </div>
                    <div class="post-body">
                        <div class="post-images">
                            <img src="https://64.media.tumblr.com/6c1e53664002e6f8c3241730be040dc5/3e00493b16879cb9-f9/s1280x1920/c2c8d514d8285049e51a9959cf5e23ba096ec229.jpg">
                            <img style="width: 100%;" src="https://64.media.tumblr.com/9c9a054561c67f1a96c178c0f8c58a8b/c753f9f6bb3ab2cc-15/s1280x1920/123706f0d8653911b1f27a23d321f5d0c5ef3c9b.gifv"><img src="https://64.media.tumblr.com/6c1e53664002e6f8c3241730be040dc5/3e00493b16879cb9-f9/s1280x1920/c2c8d514d8285049e51a9959cf5e23ba096ec229.jpg">
                            <img style="width: 100%;" src="https://64.media.tumblr.com/9c9a054561c67f1a96c178c0f8c58a8b/c753f9f6bb3ab2cc-15/s1280x1920/123706f0d8653911b1f27a23d321f5d0c5ef3c9b.gifv">
                        </div>
                        <p class="blogpost-body">
                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet.
                        </p>
                    </div>
                </div> -->
            </div>
            <div class="grid-column">
                <!-- <div class="blogpost">
                    <div class="post-account">asd</div>
                    <div class="post-body">
                        <p class="blogpost-body">
                            Lorem ipsum dolois dis partunsequat massa quis enim. Donec pcus ut, imperdiet a, v
                        </p>
                    </div>
                </div>
                <div class="blogpost">
                    <div class="post-account">piggyuser1000</div>
                    <div class="post-body">
                        <img src="https://64.media.tumblr.com/6c1e53664002e6f8c3241730be040dc5/3e00493b16879cb9-f9/s1280x1920/c2c8d514d8285049e51a9959cf5e23ba096ec229.jpg" style="width: 100%;">
                        <p class="blogpost-body">
                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet.
                        </p>
                    </div>
                </div>
                <div class="blogpost">
                    <div class="post-account">asd</div>
                    <div class="post-body">
                        <p class="blogpost-body">
                            Lorem ipsum dolois dis partunsequat massa quis enim. Donec pcus ut, imperdiet a, v
                        </p>
                    </div>
                </div>
                <div class="blogpost">
                    <div class="post-account">piggyuser1000</div>
                    <div class="post-body">
                        <p class="blogpost-body">
                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet.
                        </p>
                    </div>
                </div> -->
            </div>
            <div class="grid-column">
                <!-- <div class="blogpost">
                    <div class="post-account">piggyuser1000</div>
                    <div class="post-body">
                        <p class="blogpost-body">
                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet.
                        </p>
                    </div>
                </div>
                <div class="blogpost">
                    <div class="post-account">asd</div>
                    <div class="post-body">
                        <p class="blogpost-body">
                            Lorem ipsum dolois dis partunsequat massa quis enim. Donec pcus ut, imperdiet a, v
                        </p>
                    </div>
                </div>
                <div class="blogpost">
                    <div class="post-account">asd</div>
                    <div class="post-body">
                        <img style="width: 100%;" src="https://64.media.tumblr.com/9c9a054561c67f1a96c178c0f8c58a8b/c753f9f6bb3ab2cc-15/s1280x1920/123706f0d8653911b1f27a23d321f5d0c5ef3c9b.gifv">
                        <p class="blogpost-body">
                            hello world
                        </p>
                    </div>
                </div> -->

            </div>            
        </main>        
    </div>
    <script src="../js/recent.js"></script>
    <!-- <script src="../js/blogPostExpand.js"></script> -->
    <script src='../js/makePost.js'></script>
    <div id="post-expand-container">
        <div class="overlay" onclick="closeExpand()"></div>
        <div class="blogpost-container">
            <img id="closeExpand-btn" src="../SVG/icons8-close_w.svg" onclick="closeExpand()">
            <article class="blogpost-expanded">
                <div class="post-account-expanded">
                    <img class="pfp" src="../SVG/icons8-male-user-100.png">
                    <span>piggyuser1000</span>
                    <button class="saveBtn"></button>
                    <!-- <img src="../SVG/bookmark_w.svg" style="width: 30px; margin-inline-start: auto;"> -->
                </div>
                <div class="post-body-expanded-wrapper">
                    <div class="post-body-expanded">
                        <h1 class="blogpost-head-expanded">kjahsdnms</h1>
                        <div class="post-images-expanded">
                            <div style="display: flex; align-items: center; grid-row: 1 / 3;">
                                <img style="width: 100%" src="https://64.media.tumblr.com/6c1e53664002e6f8c3241730be040dc5/3e00493b16879cb9-f9/s1280x1920/c2c8d514d8285049e51a9959cf5e23ba096ec229.jpg">
                            </div>
                            <div style="display: flex; align-items: center;">
                                <img style="width: 100%" src="https://64.media.tumblr.com/6c1e53664002e6f8c3241730be040dc5/3e00493b16879cb9-f9/s1280x1920/c2c8d514d8285049e51a9959cf5e23ba096ec229.jpg">
                            </div>
                            <div style="display: flex; align-items: center;">
                                <img style="width: 100%" src="https://64.media.tumblr.com/6c1e53664002e6f8c3241730be040dc5/3e00493b16879cb9-f9/s1280x1920/c2c8d514d8285049e51a9959cf5e23ba096ec229.jpg">
                            </div>
                        </div>
                        <p class="blogpost-body-expanded">
                            Loraoreet.
                        </p>
                    </div>
                </div>
                
            </article>
            <div class="post-community">
                <menu class="post-menu">
                    <button class="menuBtn">
                        <img class="menu-icon" src="../SVG/heart-outline_w.svg">
                        <p id="likeCount0">0 Likes</p>
                    </button>
                    <button class="menuBtn">
                        <img class="menu-icon" src="../SVG/comment-outline_w.svg">
                        <p id="commentCount0">0 Comments</p>
                    </button>
                    <button class="menuBtn">
                        <img class="menu-icon" src="../SVG/icons8-share_w.svg">
                        <p>Share</p>
                    </button>
                </menu>
                <div class="post-comments-container">
                    <h1 class="commentsHeader">Comments</h1>
                    <div class="postComment" id="postComments0">
                        <div class="comment">
                            <img class="pfp" src="../SVG/icons8-male-user-100.png">
                            <div>
                                <h2>User</h2>
                                <p>alksdjlkasjdlkasjd asjaskj asdas</p>
                            </div>
                        </div>
                    </div>
                    <div class="postComment" id="postComments0">
                        <div class="comment">
                            <img class="pfp" src="../SVG/icons8-male-user-100.png">
                            <div>
                                <h2>User</h2>
                                <p>alksdjlkasjdlkasjd asjaskj asdas</p>
                            </div>
                        </div>
                    </div>
                    <div class="postComment" id="postComments0">
                        <div class="comment">
                            <img class="pfp" src="../SVG/icons8-male-user-100.png">
                            <div>
                                <h2>User</h2>
                                <p>alksdjlkasjdlkasjd asjaskj asdas</p>
                            </div>
                        </div>
                    </div>
                    <div class="postComment" id="postComments0">
                        <div class="comment">
                            <img class="pfp" src="../SVG/icons8-male-user-100.png">
                            <div>
                                <h2>User</h2>
                                <p>alksdjlkasjdlkasjd asjaskj asdas</p>
                            </div>
                        </div>
                    </div>
                    <div class="postComment" id="postComments0">
                        <div class="comment">
                            <img class="pfp" src="../SVG/icons8-male-user-100.png">
                            <div>
                                <h2>User</h2>
                                <p>alksdjlkasjdlkasjd asjaskj asdas</p>
                            </div>
                        </div>
                    </div>
                    <div class="postComment" id="postComments0">
                        <div class="comment">
                            <img class="pfp" src="../SVG/icons8-male-user-100.png">
                            <div>
                                <h2>User</h2>
                                <p>alksdjlkasjdlkasjd asjaskj asdas</p>
                            </div>
                        </div>
                    </div>
                    <div class="postComment" id="postComments0">
                        <div class="comment">
                            <img class="pfp" src="../SVG/icons8-male-user-100.png">
                            <div>
                                <h2>User</h2>
                                <p>alksdjlkasjdlkasjd asjaskj asdas</p>
                            </div>
                        </div>
                    </div>
                    <div class="postComment" id="postComments0">
                        <div class="comment">
                            <img class="pfp" src="../SVG/icons8-male-user-100.png">
                            <div>
                                <h2>User</h2>
                                <p>alksdjlkasjdlkasjd asjaskj asdas</p>
                            </div>
                        </div>
                    </div>
                    <div class="postComment" id="postComments0">
                        <div class="comment">
                            <img class="pfp" src="../SVG/icons8-male-user-100.png">
                            <div>
                                <h2>User</h2>
                                <p>alksdjlkasjdlkasjd asjaskj asdas</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>
