<?php
// Include the database connection
require 'db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $conn->prepare('SELECT * FROM posts');
    $stmt->execute();
    $posts = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode($posts);
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Example for adding new posts (if needed)
    $data = json_decode(file_get_contents('php://input'), true);

    if (isset($data['title']) && isset($data['content'])) {
        $stmt = $conn->prepare('INSERT INTO posts (title, content) VALUES (:title, :content)');
        $stmt->bindParam(':title', $data['title']);
        $stmt->bindParam(':content', $data['content']);
        $stmt->execute();

        echo json_encode(['message' => 'Post added successfully']);
    } else {
        http_response_code(400);
        echo json_encode(['error' => 'Invalid data']);
    }
}
?>
