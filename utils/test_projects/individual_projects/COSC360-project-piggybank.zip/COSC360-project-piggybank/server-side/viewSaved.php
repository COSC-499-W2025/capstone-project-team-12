
<?php


$servername = "localhost"; // Local environment
$username = "piggybank";
$password = "blog";
$dbname = "piggybank";


// Get user_id from session
if (!isset($_SESSION['user_id'])) {
   header('Content-Type: application/json');
   http_response_code(401);
   echo json_encode(["error" => "User not logged in"]);
   exit();
}


$user_id = intval($_SESSION['user_id']);


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
   header('Content-Type: application/json');
   http_response_code(500);
   echo json_encode(["error" => "Database connection failed: " . $conn->connect_error]);
   exit();
}


try {
   $stmt = $conn->prepare("
       SELECT p.post_id, p.user_id, p.title, p.content, p.tags as tag, p.image_url, p.created_at
       FROM posts p
       INNER JOIN saved_posts sp ON p.post_id = sp.post_id
       WHERE sp.user_id = ?
       ORDER BY sp.created_at DESC
   ");
  
   $stmt->bind_param("i", $user_id);
   $stmt->execute();
   $result = $stmt->get_result();
  
   $blogs = array();
  
   // while there are rows in the result (i.e. while there are saved posts)
   while($row = $result->fetch_assoc()) {
       // Prepare user statement to get post author's info
       $userStmt = $conn->prepare("SELECT username, profile_pic FROM users WHERE user_id = ?");
       $userStmt->bind_param("i", $row["user_id"]);
       $userStmt->execute();
       $userResult = $userStmt->get_result();
       $userInfo = $userResult->fetch_assoc();
      
       $blog = array(
           "pfp" => isset($userInfo["profile_pic"]) ? $userInfo["profile_pic"] : "SVG/icons8-male-user-100.png",
           "username" => isset($userInfo["username"]) ? $userInfo["username"] : "Anonymous",
           "content" => array(
               "blogHead" => isset($row["title"]) ? $row["title"] : "",
               "blogBody" => isset($row["content"]) ? $row["content"] : "",
               "images" => isset($row["image_url"]) ? $row["image_url"] : ""
           ),
           "tag" => isset($row["tag"]) ? $row["tag"] : "",
           "id" => $row["post_id"]
       );
      
       $blogs[] = $blog;
      
       $userStmt->close();
   }
  
   $stmt->close();
  
   header('Content-Type: application/json');
   echo json_encode($blogs);
  
} catch(Exception $e) {
   header('Content-Type: application/json');
   http_response_code(500);
   echo json_encode(["error" => "Database error: " . $e->getMessage()]);
} finally {
   $conn->close();
}
?>
