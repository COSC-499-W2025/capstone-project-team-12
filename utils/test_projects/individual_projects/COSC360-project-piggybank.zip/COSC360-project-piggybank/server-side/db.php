<?php
// Test connection script
$host = "localhost";
$username = "root";    // replace with your username
$password = "";        // replace with your password
$database = "schari02"; // replace with your database name
echo "hello";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Connected successfully!";
$conn->close();
?>
