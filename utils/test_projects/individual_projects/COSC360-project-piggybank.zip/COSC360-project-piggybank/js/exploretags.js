document.addEventListener("DOMContentLoaded", function() {
    // Check if the user is logged in
    const isLoggedIn = localStorage.getItem("loggedIn") === "true";

    if (isLoggedIn) {
        document.getElementById("logout-btn").style.display = "block";
        document.getElementById("view-account-btn").style.display = "flex";
        document.getElementById("login-btn").style.display = "none";
    } else {
        document.getElementById("logout-btn").style.display = "none";
        document.getElementById("view-account-btn").style.display = "none";
        document.getElementById("login-btn").style.display = "block";
    }

    // Handle logout
    document.getElementById("logout-btn").addEventListener("click", function() {
        // Clear login status from localStorage
        localStorage.removeItem("loggedIn");
        // Redirect to login page
        window.location.href = "./loginpage.html";
    });

    // Handle login button click
    document.getElementById("login-btn").addEventListener("click", function() {
        // Redirect to login page
        window.location.href = "./loginpage.html";
    });

    // Handle "Make Post" button click
    document.getElementById("make-post-btn").addEventListener("click", function() {
        // Check if the user is logged in
        const loggedIn = localStorage.getItem("loggedIn");
    
        if (loggedIn === "false" || loggedIn === null) {
            // If not logged in, show a popup message
            alert("User must be logged in to create posts.");
        } else {
            // If logged in, proceed with the post creation flow
            window.location.href = "makepost.html"; // or whatever logic you have for making a post
        }
    });
    
});

document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the default form submission

    // Perform your login validation here
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    // For demonstration purposes, we'll assume the login is always successful
    // In a real application, you would validate the credentials with a server

    if (email && password) {
        // Redirect to exploretags.html upon successful login
        window.location.href = "../server-side/exploretags.php";
    } else {
        // Display an error message if login fails
        alert("Invalid email or password. Please try again.");
    }
});

// Toggle password visibility
document.getElementById("togglePassword").addEventListener("click", function() {
    let passwordField = document.getElementById("password");
    if (passwordField.type === "password") {
        passwordField.type = "text";
        this.classList.replace("fa-eye-slash", "fa-eye");
    } else {
        passwordField.type = "password";
        this.classList.replace("fa-eye", "fa-eye-slash");
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const isLoggedIn = localStorage.getItem("loggedIn") === "true";

    if (isLoggedIn) {
        document.getElementById("logout-btn").style.display = "block";
        document.getElementById("view-account-btn").style.display = "flex";
        document.getElementById("login-btn").style.display = "none";
    } else {
        document.getElementById("logout-btn").style.display = "none";
        document.getElementById("view-account-btn").style.display = "none";
        document.getElementById("login-btn").style.display = "block";
    }

    document.getElementById("logout-btn").addEventListener("click", async () => {
        const response = await fetch('./server-side/logout.php');
        localStorage.setItem("loggedIn", "false");
        window.location.href = "./loginpage.html";
    });

    document.getElementById("login-btn").addEventListener("click", () => {
        window.location.href = "./loginpage.html";
    });

    document.getElementById("make-post-btn").addEventListener("click", () => {
        if (isLoggedIn) {
            window.location.href = "makepost.html";
        } else {
            alert("User must be logged in to create posts.");
        }
    });
});
