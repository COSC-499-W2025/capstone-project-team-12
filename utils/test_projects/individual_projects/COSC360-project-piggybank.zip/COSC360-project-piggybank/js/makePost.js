let imgCount = 0;
let deletedId = [];
//let deleted = false;
function addMore() {
    updateImgCount();
    let addMoreBtn = document.getElementById("addMoreBtn");
    //console.log(imgCount);
    //console.log(deletedId.length>0)
    let id = (deletedId.length>0)?deletedId.pop():imgCount;
    
    //console.log("id: "+id)

    let imageAttachment = document.createElement("div");
    imageAttachment.setAttribute("class", "imgAttachment");
    let imgUploadLabel = document.createElement("label");
    imgUploadLabel.setAttribute("for", "image"+id);
    imgUploadLabel.setAttribute("class", "addImageLabel");
    imgUploadLabel.innerText = "Add Image"+(imgCount+1);
    let imgUpload = document.createElement("input");
    imgUpload.setAttribute("type", "file"); 
    imgUpload.setAttribute("id", "image"+id);
    imgUpload.setAttribute("name", "images[]");
    imgUpload.setAttribute("accept", "image/*");
    imgUpload.style.display = "none";
    imgUpload.addEventListener("change", (e) => {
        updateImgLabel(id);
    });
    let rmFileBtn = document.createElement("button"); //type="button" class='rmFileBtn' onclick='rmFile(0)'
    rmFileBtn.setAttribute("type", "button");
    rmFileBtn.setAttribute("class", "rmFileBtn");
    //console.log("add m:"+id);
    rmFileBtn.addEventListener("click", (e) => {
        rmFile(id, e.target);
    });
    let rmFileBtnImg = document.createElement("img");
    rmFileBtnImg.src = "../SVG/icons8-close_w.svg";
    rmFileBtn.appendChild(rmFileBtnImg);
    
    imageAttachment.appendChild(imgUploadLabel);
    imageAttachment.appendChild(imgUpload);
    imageAttachment.appendChild(rmFileBtn);
    document.getElementById("imgAttachmentsWrapper").insertAdjacentElement("afterbegin", imageAttachment);

    if (imgCount > 2) {
        addMoreBtn.remove();
    }
    //deleted = false;
}

function createAddMoreBtn() {
    let btn = document.createElement("button");
    btn.setAttribute("type", "button");
    btn.setAttribute("id", "addMoreBtn");
    btn.innerText = "add more";
    btn.addEventListener("click", () => {
        addMore();
    });
    document.getElementById("imgAttachmentsContainer").insertAdjacentElement("beforeend", btn);
}

function updateImgLabel(n) {
    //console.log(n +"  " +imgCount);
    let numImages = document.getElementsByClassName("imgAttachment").length;
    for (let i = 0; i < numImages; i++) {
        //console.log("hi");
        let file = document.getElementsByClassName("imgAttachment")[i].children[1];
        if (file.value === "") {
            document.getElementsByClassName("imgAttachment")[i].children[0].innerText = "Add Image"+(numImages-i);
        }
        else {
            let filename = document.getElementsByClassName("imgAttachment")[i].children[1].files[0].name;
            document.getElementsByClassName("imgAttachment")[i].children[0].innerText = filename;
        }
    }
}

function rmFile(n, e){
    //console.log("rm imgcount: "+imgCount)
    //console.log("rm n: "+n);
    e.parentNode.parentNode.children[1].value = "";
    if (document.getElementsByClassName("imgAttachment").length > 1) {
        e.parentNode.parentNode.remove();
        deletedId.push(n);
        //deleted = true;
    }
    updateImgLabel(n);
    updateImgCount();
    if (imgCount == 3) {
        createAddMoreBtn();
    }
}

function updateImgCount() {
    imgCount = document.getElementsByClassName("imgAttachment").length;
}

// function generateCatOptions() {

// }

function draftPost() {
    alert("drafted!");
    //ajax stuff...
}

function uploadPost(e) {
    e.preventDefault();
    alert("uploaded!")
    //ajax stuff...
    window.history.back();
}