document.getElementById("blogpostForm").addEventListener("submit", function(event) {
    event.preventDefault();

    var formData = new FormData(this);

    fetch("newPost.php", {
        method: "POST",
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        console.log(data);
        alert("Post submitted successfully!");
    })
    .catch(error => {
        console.error("Error:", error);
        alert("An error occurred while submitting the post.");
    });
});