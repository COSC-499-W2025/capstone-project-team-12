document.addEventListener('DOMContentLoaded', function() {
    const editUsernameBtn = document.getElementById('editUsername');
    const editEmailBtn = document.getElementById('editEmail');
    const usernameSpan = document.getElementById('username');
    const emailSpan = document.getElementById('email');
    const editNameBtn = document.getElementById('editName');
    const nameSpan = document.getElementById('name');
    const onSpan = document.getElementById('on');
    const offSpan = document.getElementById('off');
    const yesSpan = document.getElementById('yes');
    const noSpan = document.getElementById('no');
    const changePasswordBtn = document.getElementById('changePasswordBtn');
    const passwordSection = document.getElementById('password-section');
    const passwordForm = document.getElementById('changePasswordForm');
    const cancelPasswordBtn = document.getElementById('cancelPassword');

    editUsernameBtn.addEventListener('click', function() {
        const currentUsername = usernameSpan.textContent;
        const newUsername = prompt('Enter new username:', currentUsername);
        
        if (newUsername !== null && newUsername.trim() !== '') {
            usernameSpan.textContent = newUsername;
            // Send the new username to the server using AJAX
            fetch('server-side/updateSettings.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'username=' + encodeURIComponent(newUsername)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.text();
            })
            .then(data => {
                console.log(data); // Log the response from the server
                alert('Username updated successfully!');
            })
            .catch(error => {
                console.error('There was an error updating the username:', error);
                alert('Failed to update username. Please try again.');
            });
        }
    });

    editEmailBtn.addEventListener('click', function() {
        const currentEmail = emailSpan.textContent;
        const newEmail = prompt('Enter new email:', currentEmail);
        
        if (newEmail !== null && newEmail.trim() !== '') {
            emailSpan.textContent = newEmail;
             // Send the new email to the server using AJAX
             fetch('server-side/updateSettings.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'email=' + encodeURIComponent(newEmail)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.text();
            })
            .then(data => {
                console.log(data); // Log the response from the server
                alert('Email updated successfully!');
            })
            .catch(error => {
                console.error('There was an error updating the email:', error);
                alert('Failed to update email. Please try again.');
            });
        }
    });

    editNameBtn.addEventListener('click', function() {
        const currentName = nameSpan.textContent;
        const newName = prompt('Enter new name:', currentName);
        
        if (newName !== null && newName.trim() !== '') {
            nameSpan.textContent = newName;
             // Send the new name to the server using AJAX
             fetch('server-side/updateSettings.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'name=' + encodeURIComponent(newName)
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.text();
            })
            .then(data => {
                console.log(data); // Log the response from the server
                alert('Name updated successfully!');
            })
            .catch(error => {
                console.error('There was an error updating the name:', error);
                alert('Failed to update name. Please try again.');
            });
        }
    });

    onSpan.addEventListener('click', function() {
        onSpan.classList.add('current-setting');
        offSpan.classList.remove('current-setting');
    });

    offSpan.addEventListener('click', function() {
        offSpan.classList.add('current-setting');
        onSpan.classList.remove('current-setting');
    });

    yesSpan.addEventListener('click', function() {
        yesSpan.classList.add('current-setting');
        noSpan.classList.remove('current-setting');
    });

    noSpan.addEventListener('click', function() {
        noSpan.classList.add('current-setting');
        yesSpan.classList.remove('current-setting');
    });

    changePasswordBtn.addEventListener('click', function() {
        passwordSection.style.display = 'block';
        changePasswordBtn.style.display = 'none';
        document.getElementById('privacy-settings').style.height = "85%";
        document.getElementById('privacy-settings').style.width = "25%";
    });

    cancelPasswordBtn.addEventListener('click', function() {
        passwordSection.style.display = 'none';
        changePasswordBtn.style.display = 'block';
        document.getElementById('privacy-settings').style.height = "50%";
        document.getElementById('privacy-settings').style.width = "20%";
        passwordForm.reset();
    });

   passwordForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const currentPassword = document.getElementById('currentPassword').value;
        const newPassword = document.getElementById('newPassword').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (newPassword !== confirmPassword) {
            alert('New passwords do not match!');
            return;
        }

        if (newPassword.length < 8) {
            alert('Password must be at least 8 characters long!');
            return;
        }

         // Send the password data to the server using AJAX
         fetch('server-side/updateSettings.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'currentPassword=' + encodeURIComponent(currentPassword) +
                  '&newPassword=' + encodeURIComponent(newPassword) +
                  '&confirmPassword=' + encodeURIComponent(confirmPassword)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.text();
        })
        .then(data => {
            console.log(data); // Log the response from the server
            alert(data); // Display the response from the server
            passwordSection.style.display = 'none';
            changePasswordBtn.style.display = 'block';
            passwordForm.reset();
        })
        .catch(error => {
            console.error('There was an error updating the password:', error);
            alert('Failed to update password. Please try again.');
        });
    });

});