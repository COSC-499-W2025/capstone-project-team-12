//Blog and post are used interchangeably in this file
class Blog {
    constructor(pfp, username, content, taggedUsers, id, deleteIcon, publishIcon) {
        this.pfp = pfp; // string containing profile pic image source
        this.username = username; // string containinig username
        this.content = content; // an object that contains 2 strings (1 for heading (max 80 char), 1 for body (max 2500 char)) and an array of image sources (max 4)
        this.taggedUsers = taggedUsers; // an array that contains list of usernames that have been tagged in the post
        this.id = id;   // a unique id that identifies each blog post (id is created when post is made and is saved to database)
        this.deleteIcon = deleteIcon;  //a string containing the path to the delete icon image
        this.publishIcon = publishIcon;  //a string containing the path to the publish icon image
    }
}

const blogs = [
    new Blog(
        "./SVG/icons8-male-user-100.png",
        "JaneSmith1",
        {
            blogHead:"heading",
            blogBody:"aksjhd aksjhd8iieihfh wiw.,.",
            images:["https://64.media.tumblr.com/6c1e53664002e6f8c3241730be040dc5/3e00493b16879cb9-f9/s1280x1920/c2c8d514d8285049e51a9959cf5e23ba096ec229.jpg"]
        },
        null,
        0,
        "./SVG/delete_icon.svg",
        "./SVG/publish_icon.svg"
    ),
    new Blog(
        "./SVG/icons8-male-user-100.png",
        "JaneSmith1",
        {
            blogHead:".",
            blogBody:"aksjhd aksjhd8iieihfh wiw.,.",
            images:["https://64.media.tumblr.com/9c9a054561c67f1a96c178c0f8c58a8b/c753f9f6bb3ab2cc-15/s1280x1920/123706f0d8653911b1f27a23d321f5d0c5ef3c9b.gifv"]
        },
        null,
        1,
        "./SVG/delete_icon.svg",
        "./SVG/publish_icon.svg"
    ),
    new Blog(
        "./SVG/icons8-male-user-100.png",
        "JaneSmith1",
        {
            blogHead:"",
            blogBody:"Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet.",
            images:["https://64.media.tumblr.com/6c1e53664002e6f8c3241730be040dc5/3e00493b16879cb9-f9/s1280x1920/c2c8d514d8285049e51a9959cf5e23ba096ec229.jpg", "https://64.media.tumblr.com/9c9a054561c67f1a96c178c0f8c58a8b/c753f9f6bb3ab2cc-15/s1280x1920/123706f0d8653911b1f27a23d321f5d0c5ef3c9b.gifv"]
        },
        null,
        2,
        "./SVG/delete_icon.svg",
        "./SVG/publish_icon.svg"
    ),
    new Blog(
        "./SVG/icons8-male-user-100.png",
        "JaneSmith1",
        {
            blogHead:"Moo",
            blogBody:"moo",
            images:["https://64.media.tumblr.com/9c9a054561c67f1a96c178c0f8c58a8b/c753f9f6bb3ab2cc-15/s1280x1920/123706f0d8653911b1f27a23d321f5d0c5ef3c9b.gifv","https://64.media.tumblr.com/9c9a054561c67f1a96c178c0f8c58a8b/c753f9f6bb3ab2cc-15/s1280x1920/123706f0d8653911b1f27a23d321f5d0c5ef3c9b.gifv","https://64.media.tumblr.com/9c9a054561c67f1a96c178c0f8c58a8b/c753f9f6bb3ab2cc-15/s1280x1920/123706f0d8653911b1f27a23d321f5d0c5ef3c9b.gifv"]
        },
        null,
        3,
        "./SVG/delete_icon.svg",
        "./SVG/publish_icon.svg"
    ),
    new Blog(
        "./SVG/icons8-male-user-100.png",
        "JaneSmith1",
        {
            blogHead:"",
            blogBody:"Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien. Vestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. Cras ultricies mi eu turpis hendrerit fringilla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia. Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing. Phasellus ullamcorper ipsum rutrum nunc. Nunc nonummy metus. Vestibulum volutpat pretium libero. Cras id dui. Aenean ut eros et nisl sagittis vestibulum. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede. Sed lectus. Donec mollis hendrerit risus. Phasellus nec sem in justo pellentesque facilisis. Etiam imperdiet imperdiet orci. Nunc nec neque. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa..",
            images:["https://64.media.tumblr.com/6c1e53664002e6f8c3241730be040dc5/3e00493b16879cb9-f9/s1280x1920/c2c8d514d8285049e51a9959cf5e23ba096ec229.jpg","https://64.media.tumblr.com/9c9a054561c67f1a96c178c0f8c58a8b/c753f9f6bb3ab2cc-15/s1280x1920/123706f0d8653911b1f27a23d321f5d0c5ef3c9b.gifv","https://64.media.tumblr.com/6c1e53664002e6f8c3241730be040dc5/3e00493b16879cb9-f9/s1280x1920/c2c8d514d8285049e51a9959cf5e23ba096ec229.jpg"]
        },
        null,
        4,
        "./SVG/delete_icon.svg",
        "./SVG/publish_icon.svg"
    ),
    new Blog(
        "./SVG/icons8-male-user-100.png",
        "JaneSmith1",
        {
            blogHead:"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
            blogBody:"aksjhd aksjhd8iieihfh wiw.,.",
            images:["https://64.media.tumblr.com/6c1e53664002e6f8c3241730be040dc5/3e00493b16879cb9-f9/s1280x1920/c2c8d514d8285049e51a9959cf5e23ba096ec229.jpg","https://64.media.tumblr.com/9c9a054561c67f1a96c178c0f8c58a8b/c753f9f6bb3ab2cc-15/s1280x1920/123706f0d8653911b1f27a23d321f5d0c5ef3c9b.gifv","https://64.media.tumblr.com/9c9a054561c67f1a96c178c0f8c58a8b/c753f9f6bb3ab2cc-15/s1280x1920/123706f0d8653911b1f27a23d321f5d0c5ef3c9b.gifv","https://64.media.tumblr.com/6c1e53664002e6f8c3241730be040dc5/3e00493b16879cb9-f9/s1280x1920/c2c8d514d8285049e51a9959cf5e23ba096ec229.jpg"]
        },
        null,
        5,
        "./SVG/delete_icon.svg",
        "./SVG/publish_icon.svg"
    ),
    new Blog(
        "./SVG/icons8-male-user-100.png",
        "JaneSmith1",
        {
            blogHead:"To Lorem ipsum or not to Lorem ipsum: A deep dive into Lorem Ipsuming",
            blogBody:"Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien. Vestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. Cras ultricies mi eu turpis hendrerit fringilla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia. Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing. Phasellus ullamcorper ipsum rutrum nunc. Nunc nonummy metus. Vestibulum volutpat pretium libero. Cras id dui. Aenean ut eros et nisl sagittis vestibulum. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede. Sed lectus. Donec mollis hendrerit risus. Phasellus nec sem in justo pellentesque facilisis. Etiam imperdiet imperdiet orci. Nunc nec neque. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa..",
            images:[]
        },
        null,
        6,
        "./SVG/delete_icon.svg",
        "./SVG/publish_icon.svg"
    )
];

const blogGridColumns = document.getElementsByClassName("grid-column");
let columnCounter = 0;
function insertBlogs() {
    for (let i = 0; i < blogs.length; i++) {
        blogGridColumns[columnCounter].appendChild(createBlogPost(blogs[i], false));
        if (++columnCounter > blogGridColumns.length-1) {
            columnCounter = 0;
        }
    }   
}

// returns a document fragment that contains the html structure and contents of a blog post
function createBlogPost(blog, isExpand) {
    let documentFragment = document.createDocumentFragment();
    let blogContainer = document.createElement("article"); //parent container that contains blog
    blogContainer.addEventListener("click", () => {blogExpand(blog.id, isExpand)});
    let postAccount = document.createElement("div");  // container for blog header
    let postBodyWrapper = document.createElement("div");
    let postBody = document.createElement("div");    // container for blog body

    documentFragment.appendChild(blogContainer);
    blogContainer.appendChild(postAccount);
    blogContainer.appendChild(postBodyWrapper);
    postBodyWrapper.appendChild(postBody);

    // create the pfp and username of blog creator to put in header
    let postAccount_pfp = document.createElement("img");
    postAccount_pfp.src = blog.pfp;
    let postAccount_name = document.createElement("span");
    postAccount_name.innerText = blog.username;
    let postAccount_delete = document.createElement("button");
    postAccount_delete.className = "delete-btn";
    let deleteIcon = document.createElement("img");
    deleteIcon.src = blog.deleteIcon;
    deleteIcon.alt = "delete draft";
    deleteIcon.title = "delete draft";
    postAccount_delete.appendChild(deleteIcon);
    let postAccount_publish = document.createElement("button");
    postAccount_publish.className = "publish-btn";
    let publishIcon = document.createElement("img");
    publishIcon.src = blog.publishIcon;
    publishIcon.alt = "publish draft";
    publishIcon.title = "publish draft";  // Correct element
    postAccount_publish.appendChild(publishIcon);
    postAccount_delete.addEventListener("click", (e) => {
        deletePost(blog.id);
        e.stopPropagation(); // Prevents blog expansion when clicking delete
    });
    postAccount_publish.addEventListener("click", (e) => {
        deletePost(blog.id);
        e.stopPropagation(); // Prevents blog expansion when clicking delete
    });


    postAccount.appendChild(postAccount_pfp);
    postAccount.appendChild(postAccount_name);
    postAccount.appendChild(postAccount_delete);
    postAccount.appendChild(postAccount_publish);

    // create blog content (heading(if exist), image(if exist), and text) to put in body
    // blog heading
    let postBlogHead = document.createElement("h1"); 
    if(blog.content.blogHead.trim() !== "") {
        postBlogHead.innerText = blog.content.blogHead;
        postBody.appendChild(postBlogHead);
    }
    // blog images
    let imgCount = blog.content.images.length;
    let postImages = document.createElement("div");
    if (imgCount > 0) {
        postBody.appendChild(postImages);
        for (let i = 0; i < imgCount; i++) {
            let imgDiv = document.createElement("div");
            imgDiv.style.display = "flex";
            imgDiv.style.alignItems = "center";
            if(imgCount == 3 && i == 0) {
                imgDiv.style.gridRow = "1/3";
            }
            let img = document.createElement("img");
            img.src = blog.content.images[i];
            postImages.appendChild(imgDiv);
            imgDiv.appendChild(img);    
        }
    }
    // blog body
    let postBlogBody = document.createElement("p");
    postBlogBody.innerText = blog.content.blogBody;
    postBody.appendChild(postBlogBody);

    // set classes to elements to style depending on if it is normal view or expanded view
    if (isExpand) {
        blogContainer.setAttribute("class", "blogpost-expanded");
        postAccount.setAttribute("class", "post-account-expanded");
        postBodyWrapper.setAttribute("class", "post-body-expanded-wrapper");
        postBody.setAttribute("class", "post-body-expanded");
        postBlogHead.setAttribute("class", "blogpost-head-expanded");
        postImages.setAttribute("class", "post-images-expanded");
        postBlogBody.setAttribute("class", "blogpost-body-expanded");
    }
    else {
        blogContainer.setAttribute("class", "blogpost");
        postAccount.setAttribute("class", "post-account");
        postBody.setAttribute("class", "post-body");
        postBlogHead.setAttribute("class", "blogpost-head");
        postImages.setAttribute("class", "post-images");
        postBlogBody.setAttribute("class", "blogpost-body");
    }
    postAccount_pfp.setAttribute("class", "pfp");

    return documentFragment;
}

function deletePost(blogId) {
    let index = blogs.map(x => {
        return x.id;
    }).indexOf(blogId);
    blogs.splice(index, 1);

    for(let i = 0; i < blogGridColumns.length; i++){
        blogGridColumns[i].replaceChildren();
    }
    columnCounter = 0;
    insertBlogs();
}

function blogExpand(blogId, isExpanded) {
    if (!isExpanded) {
        let postExpandContainer = document.createElement("div");    // create container that will wrap all expanded content and overlays entire screen 
        postExpandContainer.setAttribute("id", "post-expand-container");
        let overlay = document.createElement("div");    // an invisible container will allow "clicking outside to close"
        overlay.setAttribute("class", "overlay");
        overlay.addEventListener("click", () => {closeExpand()});
        let blogPostContainer = document.createElement("div");  // container that wraps the blog post, menu, and comments section
        blogPostContainer.setAttribute("class", "blogpost-container");
        
        postExpandContainer.appendChild(overlay);
        postExpandContainer.appendChild(blogPostContainer);
        
        let closeBtn = document.createElement("img");   // create close button to "exit" expanded blog post
        closeBtn.setAttribute("id", "closeExpand-btn");
        closeBtn.src = "./SVG/icons8-close_w.svg";
        closeBtn.addEventListener("click", () => {closeExpand()});
        let expandedBlog = createBlogPost(blogs[blogId], true); // the actual blog content
        let communitySection = document.createElement("div");   // container that wraps the menu and comments section
        communitySection.setAttribute("class", "post-community");

        blogPostContainer.appendChild(closeBtn);
        blogPostContainer.appendChild(expandedBlog);
        blogPostContainer.appendChild(communitySection);

        let postMenu = document.createElement("menu");  // menu (i.e. likes, comments, share... buttons)
        postMenu.setAttribute("class", "post-menu");
        let postComments = document.createElement("div");   // comments section
        postComments.setAttribute("class", "post-comments")

        communitySection.appendChild(postMenu);
        communitySection.appendChild(postComments);

        document.body.insertAdjacentElement("beforeend", postExpandContainer);
    }
}
// "closes/exits" the expanded blog post
function closeExpand() {
    document.getElementById("post-expand-container").remove();
}

window.onload = function() {
    insertBlogs();
};