function fetchBlogs() {
    fetch('viewSaved.php')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Convert plain objects to Blog instances
            blogs = data.map(blog => new Blog(
                blog.pfp,
                blog.username,
                blog.content,
                blog.tag,
                blog.id
            ));
                        // Now insert the blogs into the HTML
                        insertBlogs();
                    })
                    .catch(error => {
                        console.error('Error fetching blog data:', error);
 
 
                        // showing error message to user//Blog and post are used interchangeably in this file
 // class Blog {
 //     constructor(pfp, username, content, taggedUsers, id) {
 //         this.pfp = pfp; // string containing profile pic image source
 //         this.username = username; // string containinig username
 //         this.content = content; // an object that contains 2 strings (1 for heading (max 80 char), 1 for body (max 2500 char)) and an array of image sources (max 4)
 //         this.taggedUsers = taggedUsers; // an array that contains list of usernames that have been tagged in the post
 //         this.id = id;   // a unique id that identifies each blog post (id is created when post is made and is saved to database)
 //     }
 //  }
 
 
 let blogs = []; // Will be populated from PHP
 
 
 // Fetch blog data from the server
 
 
                        let errorMessage = document.createElement("h1");
                        errorMessage.style.opacity = "0.7";
                        errorMessage.style.fontWeight = "lighter";
                        errorMessage.innerText = "Error loading posts";
                        document.getElementById("account-content").style.display = "block";
                        document.getElementById("account-content").appendChild(errorMessage);
                    });
            }
 
 
 
 
 // const blogs = [.....
 
 
 
 
 // returns a document fragment that contains the html structure and contents of a blog post
 function createBlogPost(blog, isExpand) {
    let documentFragment = document.createDocumentFragment();
    let blogContainer = document.createElement("article"); //parent container that contains blog
    blogContainer.addEventListener("click", () => {blogExpand(blog.id, isExpand)});
    let postAccount = document.createElement("div");  // container for blog header
    let postBodyWrapper = document.createElement("div");
    let postBody = document.createElement("div");    // container for blog body
 
 
    documentFragment.appendChild(blogContainer);
    blogContainer.appendChild(postAccount);
    blogContainer.appendChild(postBodyWrapper);
    postBodyWrapper.appendChild(postBody);
 
 
    // create the pfp and username of blog creator to put in header
    let postAccount_pfp = document.createElement("img");
    postAccount_pfp.src = blog.pfp;
    let postAccount_name = document.createElement("span");
    postAccount_name.innerText = blog.username;
    let postAccount_delete = document.createElement("button");
    postAccount_delete.className = "delete-btn";
    let deleteIcon = document.createElement("img");
    deleteIcon.src = blog.deleteIcon;
    deleteIcon.alt = "remove from saved";
    deleteIcon.title = "remove from saved";
    postAccount_delete.appendChild(deleteIcon);
    postAccount_delete.addEventListener("click", (e) => {
        deletePost(blog.id);
        e.stopPropagation(); // Prevents blog expansion when clicking delete
    });
 
 
 
 
    postAccount.appendChild(postAccount_pfp);
    postAccount.appendChild(postAccount_name);
    postAccount.appendChild(postAccount_delete);
 
 
    // create blog content (heading(if exist), image(if exist), and text) to put in body
    // blog heading
    let postBlogHead = document.createElement("h1");
    if(blog.content.blogHead.trim() !== "") {
        postBlogHead.innerText = blog.content.blogHead;
        postBody.appendChild(postBlogHead);
    }
    // blog images
    let imgCount = blog.content.images.length;
    let postImages = document.createElement("div");
    if (imgCount > 0) {
        postBody.appendChild(postImages);
        for (let i = 0; i < imgCount; i++) {
            let imgDiv = document.createElement("div");
            imgDiv.style.display = "flex";
            imgDiv.style.alignItems = "center";
            if(imgCount == 3 && i == 0) {
                imgDiv.style.gridRow = "1/3";
            }
            let img = document.createElement("img");
            img.src = blog.content.images[i];
            postImages.appendChild(imgDiv);
            imgDiv.appendChild(img);   
        }
    }
    // blog body
    let postBlogBody = document.createElement("p");
    postBlogBody.innerText = blog.content.blogBody;
    postBody.appendChild(postBlogBody);
 
 
    // set classes to elements to style depending on if it is normal view or expanded view
    if (isExpand) {
        blogContainer.setAttribute("class", "blogpost-expanded");
        postAccount.setAttribute("class", "post-account-expanded");
        postBodyWrapper.setAttribute("class", "post-body-expanded-wrapper");
        postBody.setAttribute("class", "post-body-expanded");
        postBlogHead.setAttribute("class", "blogpost-head-expanded");
        postImages.setAttribute("class", "post-images-expanded");
        postBlogBody.setAttribute("class", "blogpost-body-expanded");
    }
    else {
        blogContainer.setAttribute("class", "blogpost");
        postAccount.setAttribute("class", "post-account");
        postBody.setAttribute("class", "post-body");
        postBlogHead.setAttribute("class", "blogpost-head");
        postImages.setAttribute("class", "post-images");
        postBlogBody.setAttribute("class", "blogpost-body");
    }
    postAccount_pfp.setAttribute("class", "pfp");
 
 
    return documentFragment;
 }
 
 
 function deletePost(blogId) {
    let index = blogs.map(x => {
        return x.id;
    }).indexOf(blogId);
    blogs.splice(index, 1);
 
 
    for(let i = 0; i < blogGridColumns.length; i++){
        blogGridColumns[i].replaceChildren();
    }
    columnCounter = 0;
    insertBlogs();
 }
 
 
 function blogExpand(blogId, isExpanded) {
    if (!isExpanded) {
        let postExpandContainer = document.createElement("div");    // create container that will wrap all expanded content and overlays entire screen
        postExpandContainer.setAttribute("id", "post-expand-container");
        let overlay = document.createElement("div");    // an invisible container will allow "clicking outside to close"
        overlay.setAttribute("class", "overlay");
        overlay.addEventListener("click", () => {closeExpand()});
        let blogPostContainer = document.createElement("div");  // container that wraps the blog post, menu, and comments section
        blogPostContainer.setAttribute("class", "blogpost-container");
       
        postExpandContainer.appendChild(overlay);
        postExpandContainer.appendChild(blogPostContainer);
       
        let closeBtn = document.createElement("img");   // create close button to "exit" expanded blog post
        closeBtn.setAttribute("id", "closeExpand-btn");
        closeBtn.src = "./SVG/icons8-close_w.svg";
        closeBtn.addEventListener("click", () => {closeExpand()});
        let expandedBlog = createBlogPost(blogs[blogId], true); // the actual blog content
        let communitySection = document.createElement("div");   // container that wraps the menu and comments section
        communitySection.setAttribute("class", "post-community");
 
 
        blogPostContainer.appendChild(closeBtn);
        blogPostContainer.appendChild(expandedBlog);
        blogPostContainer.appendChild(communitySection);
 
 
        let postMenu = document.createElement("menu");  // menu (i.e. likes, comments, share... buttons)
        postMenu.setAttribute("class", "post-menu");
        let postComments = document.createElement("div");   // comments section
        postComments.setAttribute("class", "post-comments")
 
 
        communitySection.appendChild(postMenu);
        communitySection.appendChild(postComments);
 
 
        document.body.insertAdjacentElement("beforeend", postExpandContainer);
    }
 }
 // "closes/exits" the expanded blog post
 function closeExpand() {
    document.getElementById("post-expand-container").remove();
 }
 
 
 window.onload = function() {
    insertBlogs();
 };
 