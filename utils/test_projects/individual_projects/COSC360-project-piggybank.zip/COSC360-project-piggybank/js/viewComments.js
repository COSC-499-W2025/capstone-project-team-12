document.addEventListener('DOMContentLoaded', function() {
  // Function to fetch comments from the server
  function fetchComments() {
    fetch('server-side/getComments.php')
      .then(response => response.json())
      .then(data => {
        const commentsContainer = document.getElementById('comments-container');

        // Check if the container exists
        if (!commentsContainer) {
          console.error('Comments container not found in viewComments.html');
          return;
        }

        // Clear any existing content in the container
        commentsContainer.innerHTML = '';

        if (Array.isArray(data) && data.length > 0) {
          // Loop through the comments and display them
          data.forEach(comment => {
            const commentDiv = document.createElement('div');
            commentDiv.classList.add('comment'); 

            // Display username
            const username = document.createElement('p');
            username.style.fontWeight = 'bold';
            username.textContent = comment.username;
            commentDiv.appendChild(username);

            // Display comment text
            const commentText = document.createElement('p');
            commentText.textContent = comment.comment_text;
            commentDiv.appendChild(commentText);

            // Append comment div to container
            commentsContainer.appendChild(commentDiv);
          });
        } else {
          // Display dummy comments if no comments found or if there's an error
          const dummyComments = [
            { username: 'DummyUser1', comment_text: 'This is a dummy comment 1.' },
            { username: 'DummyUser2', comment_text: 'This is a dummy comment 2.' },
            { username: 'DummyUser3', comment_text: 'This is a dummy comment 3.' }
          ];

          dummyComments.forEach(comment => {
            const commentDiv = document.createElement('div');
            commentDiv.classList.add('comment'); 

            // Display username
            const username = document.createElement('p');
            username.style.fontWeight = 'bold';
            username.textContent = comment.username;
            commentDiv.appendChild(username);

            // Display comment text
            const commentText = document.createElement('p');
            commentText.textContent = comment.comment_text;
            commentDiv.appendChild(commentText);

            // Append comment div to container
            commentsContainer.appendChild(commentDiv);
          });
        }
      })
      .catch(error => {
        console.error('Error fetching comments:', error);
        const commentsContainer = document.getElementById('comments-container');

        // Display dummy comments if there's an error
        const dummyComments = [
          { username: 'DummyUser1 (Error)', comment_text: 'This is a dummy comment 1 (Error).' },
          { username: 'DummyUser2 (Error)', comment_text: 'This is a dummy comment 2 (Error).' },
          { username: 'DummyUser3 (Error)', comment_text: 'This is a dummy comment 3 (Error).' }
        ];

        dummyComments.forEach(comment => {
          const commentDiv = document.createElement('div');
          commentDiv.classList.add('comment'); 

          // Display username
          const username = document.createElement('p');
          username.style.fontWeight = 'bold';
          username.textContent = comment.username;
          commentDiv.appendChild(username);

          // Display comment text
          const commentText = document.createElement('p');
          commentText.textContent = comment.comment_text;
          commentDiv.appendChild(commentText);

          // Append comment div to container
          commentsContainer.appendChild(commentDiv);
        });
      });
  }

  fetchComments();
});