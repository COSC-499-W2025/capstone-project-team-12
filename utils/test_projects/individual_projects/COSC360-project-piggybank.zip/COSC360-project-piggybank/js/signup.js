document.getElementById("signupForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the default form submission

    const firstName = document.getElementById("firstName").value;
    const lastName = document.getElementById("lastName").value;
    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    if (firstName && lastName && username && email && password) {
        // Display the success message
        document.getElementById("successMessage").style.display = "block";
    } else {
        // Display an error message if signup fails
        alert("Please fill in all fields.");
    }
});

// Directs to login page on "Want to login?" button click
document.getElementById("login-btn").addEventListener("click", function() {
    window.location.href = "./loginpage.html";
});