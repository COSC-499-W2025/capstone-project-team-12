//Blog and post are used interchangeably in this file
// class Blog {
//     constructor(pfp, username, content, taggedUsers, id) {
//         this.pfp = pfp; // string containing profile pic image source
//         this.username = username; // string containinig username
//         this.content = content; // an object that contains 2 strings (1 for heading (max 80 char), 1 for body (max 2500 char)) and an array of image sources (max 4)
//         this.taggedUsers = taggedUsers; // an array that contains list of usernames that have been tagged in the post
//         this.id = id;   // a unique id that identifies each blog post (id is created when post is made and is saved to database)
//     }
//  }


let blogs = []; // Will be populated from PHP


// Fetch blog data from the server
function fetchBlogs(source = '../server-side/viewAccount.php') {
   fetch(source)
       .then(response => {
           if (!response.ok) {
               throw new Error('Network response was not ok');
           }
           return response.json();
       })
       .then(data => {
           blogs = data.map(blog => new Blog(
               blog.pfp,
               blog.username,
               blog.content,
               blog.tag,
               blog.id
           ));
          
           insertBlogs();
           // Update the post count in viewAccount.html
           const postCountElement = document.getElementById('post-count');
           if (postCountElement) {
               postCountElement.textContent = blogs.length;
           }
       })
       .catch(error => {
           console.error('Error fetching blog data:', error);
          
           // showing error message to user
           let errorMessage = document.createElement("h1");
           errorMessage.style.opacity = "0.7";
           errorMessage.style.fontWeight = "lighter";
           errorMessage.innerText = "Error loading posts";
           document.getElementById("account-content").style.display = "block";
           document.getElementById("account-content").appendChild(errorMessage);
       });
}






const blogGridColumns = document.getElementsByClassName("grid-column");
let columnCounter = 0;
function insertBlogs() {
   if (blogs.length < 1) { // if no posts, show "no posts" message
       let noPostsMessage = document.createElement("h1");
       noPostsMessage.style.opacity = "0.7";
       noPostsMessage.style.fontWeight = "lighter";
       noPostsMessage.innerText = "no posts";
       document.getElementById("account-content").style.display = "block";
       document.getElementById("account-content").appendChild(noPostsMessage);
   }
   else {
       document.getElementById("account-content").style.removeProperty("display");
       for (let i = 0; i < blogs.length; i++) {
           blogGridColumns[columnCounter].appendChild(createBlogPost(blogs[i], false));
           if (++columnCounter > blogGridColumns.length-1) {
               columnCounter = 0;
           }
       }
   }
    
}


// returns a document fragment that contains the html structure and contents of a blog post
function createBlogPost(blog, isExpand) {
   let documentFragment = document.createDocumentFragment();
   let blogContainer = document.createElement("article"); //parent container that contains blog
   blogContainer.addEventListener("click", () => {blogExpand(blog.id, isExpand)});
   let postAccount = document.createElement("div");  // container for blog header
   let postBodyWrapper = document.createElement("div");
   let postBody = document.createElement("div");    // container for blog body


   // expanded blog posts do not have the option to edit and delete
   if (!isExpand) {
       let wrapperDiv = document.createElement("div");
       wrapperDiv.style.position = "relative";
       let postDropupContent = document.createElement("div");
       postDropupContent.setAttribute("onmouseleave", "closePostMenu(this)");
       let postDropupMenuWrapper = document.createElement("div");
       let postDropupEditBtn = document.createElement("button");
       postDropupEditBtn.innerText = "Edit";
       let postDropupDeleteBtn = document.createElement("button");
       postDropupDeleteBtn.innerText = "Delete";
       documentFragment.appendChild(wrapperDiv);
       wrapperDiv.appendChild(blogContainer);
       blogContainer.appendChild(postAccount);
       blogContainer.appendChild(postBodyWrapper);
       postBodyWrapper.appendChild(postBody);
       blogContainer.appendChild(postDropupContent);
       postDropupContent.appendChild(postDropupMenuWrapper);
       postDropupMenuWrapper.appendChild(postDropupEditBtn);
       postDropupMenuWrapper.appendChild(postDropupDeleteBtn);


       postDropupContent.setAttribute("class", "post-dropup-content");
       postDropupEditBtn.setAttribute("class", "post-menu-btn");
       postDropupEditBtn.addEventListener("click", (e) => {
           editPost(blog.id);
           e.stopPropagation();
       });
       postDropupDeleteBtn.setAttribute("class", "post-menu-btn");
       postDropupDeleteBtn.addEventListener("click", (e) => {
           deletePost(blog.id);
           e.stopPropagation();
       });
   }
   else {
       documentFragment.appendChild(blogContainer);
       blogContainer.appendChild(postAccount);
       blogContainer.appendChild(postBodyWrapper);
       postBodyWrapper.appendChild(postBody);
   }
  


   // create the pfp and username of blog creator to put in header
   let postAccount_pfp = document.createElement("img");
   postAccount_pfp.src = blog.pfp;
   let postAccount_name = document.createElement("a");
   postAccount_name.innerText = blog.username;
   postAccount_name.href = "server-side/viewUser.php?username=" + encodeURIComponent(blog.username);
   postAccount_name.addEventListener("click", (e) => {
       e.stopPropagation(); // This prevents the blog expansion when clicking the username
   });
  
   postAccount.appendChild(postAccount_pfp);
   postAccount.appendChild(postAccount_name);
  
   if (!isExpand) {
       let postMenuDots = document.createElement("span");
       postMenuDots.setAttribute("class", "post-menu-dots");
       postMenuDots.setAttribute("onclick", "showPostMenu(this)");
       postMenuDots.addEventListener("click", (e) => {e.stopPropagation();});
       let menuDots = document.createElement("img");
       menuDots.src ="./SVG/menu-dots-vertical_w.svg";
       menuDots.style.height = "24px";
       postAccount.appendChild(postMenuDots);
       postMenuDots.appendChild(menuDots);
   }


   // create blog content (heading(if exist), image(if exist), and text) to put in body
   // blog heading
   let postBlogHead = document.createElement("h1");
   if(blog.content.blogHead.trim() !== "") {
       postBlogHead.innerText = blog.content.blogHead;
       postBody.appendChild(postBlogHead);
   }
   // blog images
   let imgCount = blog.content.images.length;
   let postImages = document.createElement("div");
   if (imgCount > 0) {
       postBody.appendChild(postImages);
       for (let i = 0; i < imgCount; i++) {
           let imgDiv = document.createElement("div");
           imgDiv.style.display = "flex";
           imgDiv.style.alignItems = "center";
           if(imgCount == 3 && i == 0) {
               imgDiv.style.gridRow = "1/3";
           }
           let img = document.createElement("img");
           img.src = blog.content.images[i];
           postImages.appendChild(imgDiv);
           imgDiv.appendChild(img);   
       }
   }
   // blog body
   let postBlogBody = document.createElement("p");
   postBlogBody.innerText = blog.content.blogBody;
   postBody.appendChild(postBlogBody);


   // set classes to elements to style depending on if it is normal view or expanded view
   if (isExpand) {
       blogContainer.setAttribute("class", "blogpost-expanded");
       postAccount.setAttribute("class", "post-account-expanded");
       postBodyWrapper.setAttribute("class", "post-body-expanded-wrapper");
       postBody.setAttribute("class", "post-body-expanded");
       postBlogHead.setAttribute("class", "blogpost-head-expanded");
       postImages.setAttribute("class", "post-images-expanded");
       postBlogBody.setAttribute("class", "blogpost-body-expanded");
   }
   else {
       blogContainer.setAttribute("class", "blogpost");
       postAccount.setAttribute("class", "post-account");
       postBody.setAttribute("class", "post-body");
       postBlogHead.setAttribute("class", "blogpost-head");
       postImages.setAttribute("class", "post-images");
       postBlogBody.setAttribute("class", "blogpost-body");
   }
   postAccount_pfp.setAttribute("class", "pfp");


   return documentFragment;
}


function blogExpand(blogId, isExpanded) {
   if (!isExpanded) {
       let postExpandContainer = document.createElement("div");    // create container that will wrap all expanded content and overlays entire screen
       postExpandContainer.setAttribute("id", "post-expand-container");
       let overlay = document.createElement("div");    // an invisible container will allow "clicking outside to close"
       overlay.setAttribute("class", "overlay");
       overlay.addEventListener("click", () => {closeExpand()});
       let blogPostContainer = document.createElement("div");  // container that wraps the blog post, menu, and comments section
       blogPostContainer.setAttribute("class", "blogpost-container");
      
       postExpandContainer.appendChild(overlay);
       postExpandContainer.appendChild(blogPostContainer);
      
       let closeBtn = document.createElement("img");   // create close button to "exit" expanded blog post
       closeBtn.setAttribute("id", "closeExpand-btn");
       closeBtn.src = "./SVG/icons8-close_w.svg";
       closeBtn.addEventListener("click", () => {closeExpand()});
       let expandedBlog = createBlogPost(blogs[blogId], true); // the actual blog content
       let communitySection = document.createElement("div");   // container that wraps the menu and comments section
       communitySection.setAttribute("class", "post-community");


       blogPostContainer.appendChild(closeBtn);
       blogPostContainer.appendChild(expandedBlog);
       blogPostContainer.appendChild(communitySection);


       let postMenu = document.createElement("menu");  // menu (i.e. likes, comments, share... buttons)
       postMenu.setAttribute("class", "post-menu");
       let postComments = document.createElement("div");   // comments section
       postComments.setAttribute("class", "post-comments")


       communitySection.appendChild(postMenu);
       communitySection.appendChild(postComments);


       document.body.insertAdjacentElement("beforeend", postExpandContainer);
   }
}
// "closes/exits" the expanded blog post
function closeExpand() {
   document.getElementById("post-expand-container").remove();
}
function showPostMenu(elem) {
   // alert(elem);
   elem.parentNode.parentNode.children[2].style.display = "block";
}
function closePostMenu(elem) {
   // alert(elem);
   elem.style.display = "none";
}
// const postDropupContent = document.getElementsByClassName("post-dropup-content");
// for (let i = 0; i < postDropupContent.length; i++) {
//     postDropupContent[i].addEventListener("mouseleave", (e) => {
//         // document.getElementsByClassName("post-dropup-content")[i].style.display = "none";
//         // e.target.parentNode.parentNode.parentNode.children[2].style.display = "none";
//         // e.target.parentNode.parentNode.parentNode.children[2].style.display = "none";
//         postDropupContent[i].style.display = "none";
//     });
// }


function deletePost(blogId) {
   let index = blogs.map(x => {
       return x.id;
   }).indexOf(blogId);
   blogs.splice(index, 1);


   for(let i = 0; i < blogGridColumns.length; i++){
       blogGridColumns[i].replaceChildren();
   }
   columnCounter = 0;
   insertBlogs();
}


function editPost(blogId) {
   alert("Upgrade to Premium to unlock this feature!")
}


window.onload = function() {
   insertBlogs();
};


document.addEventListener('DOMContentLoaded', fetchBlogs);