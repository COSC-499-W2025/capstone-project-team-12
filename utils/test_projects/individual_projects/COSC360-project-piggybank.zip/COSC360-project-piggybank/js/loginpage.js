console.log("loginpage.js loaded");


    document.getElementById("loginForm").addEventListener("submit", async function(event) {
        event.preventDefault(); 

        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;

        const response = await fetch('./server-side/login.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });

        const data = await response.json();

        if (data.success) {
            localStorage.setItem("loggedIn", "true");
            window.location.href = "../server-side/exploretags.php";
        } else {
            alert(data.message);
        }
        if (email && password) {
            localStorage.setItem("loggedIn", "true");
            window.location.href = "../server-side/exploretags.php";
        } else {
            alert("Invalid email or password. Please try again.");
        }
    });

    document.getElementById("togglePassword").addEventListener("click", function() {
        let passwordField = document.getElementById("password");
        if (passwordField.type === "password") {
            passwordField.type = "text";
            this.classList.replace("fa-eye-slash", "fa-eye");
        } else {
            passwordField.type = "password";
            this.classList.replace("fa-eye", "fa-eye-slash");
        }
    });

    // document.getElementById("browse-btn").addEventListener("click", function() {
    //     // localStorage.setItem("loggedIn", "false"); // Ensure the user is marked as not logged in
    //     window.location.href = "/server-side/exploretags.php";
    // });

