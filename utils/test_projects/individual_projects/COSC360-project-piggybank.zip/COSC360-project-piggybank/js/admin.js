document.addEventListener('DOMContentLoaded', function() {
    const searchForm = document.getElementById('search-form');
    const resultsTableBody = document.getElementById('results-table').querySelector('tbody');

    searchForm.addEventListener('submit', function(event) {
        event.preventDefault(); 

        const searchBy = document.getElementById('search-by').value;
        let searchTerm = document.getElementById('search-term').value;

        // Construct the URL for the AJAX request
        const url = `server-side/admin.php?search-by=${searchBy}&search-term=${searchTerm}`;

        // Make the AJAX request
        fetch(url)
            .then(response => response.json())
            .then(data => {
                // Clear the existing table rows
                resultsTableBody.innerHTML = '';

                if (Array.isArray(data)) {
                    // Iterate over results and create table rows
                    data.forEach(user => {
                        const row = document.createElement('tr');

                        const idCell = document.createElement('td');
                        idCell.textContent = user.id;
                        row.appendChild(idCell);

                        const usernameCell = document.createElement('td');
                        usernameCell.textContent = user.username;
                        row.appendChild(usernameCell);

                        const emailCell = document.createElement('td');
                        emailCell.textContent = user.email;
                        row.appendChild(emailCell);

                        const postsCell = document.createElement('td');
                        postsCell.textContent = user.post_count;
                        row.appendChild(postsCell);

                        resultsTableBody.appendChild(row);
                    });
                } else {
                    // Display a message if no users are found
                    const row = document.createElement('tr');
                    const messageCell = document.createElement('td');
                    messageCell.textContent = data.message || 'No users found.';
                    messageCell.colSpan = 4; 
                    row.appendChild(messageCell);
                    resultsTableBody.appendChild(row);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                resultsTableBody.innerHTML = '<tr><td colspan="4">An error occurred while fetching data.</td></tr>';
            });
    });

    const viewStatsBtn = document.getElementById('view-stats-btn');
    const statsFilter = document.getElementById('stats-filter');
    const statsDisplay = document.getElementById('stats-display');

    viewStatsBtn.addEventListener('click', function() {
        const statsType = statsFilter.value;
        const url = `server-side/admin.php?stats=${statsType}`;

        fetch(url)
            .then(response => response.json())
            .then(data => {
                if (data.hasOwnProperty('count')) {
                    statsDisplay.textContent = `Number of ${statsType}: ${data.count}`;
                } else if (data.hasOwnProperty('message')) {
                    statsDisplay.textContent = data.message;
                } else {
                    statsDisplay.textContent = 'Error fetching stats.';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                statsDisplay.textContent = 'Error fetching stats.';
            });
    });
});