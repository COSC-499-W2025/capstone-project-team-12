# Project Description

A Piggybank is a blogging platform that allows users to create accounts, write blogs, read blogs, and engage with content through comments, likes, and interactions. The platform features three types of users: unregistered users, registered users, and admin users. Unregistered users can browse and search through blog posts freely, without the need to register, whereas registered users must login to create their own blog posts and engage with others. Admin users can oversee content and monitor activities, with the power to delete posts, comments, or ban users when necessary.  

Figma Prototype Link: https://www.figma.com/proto/pUsUAD8DAnAIvOSfLiVd2s/360-Project-Proposal?node-id=0-1&t=QglClw6SJUNUsl7R-1

## User Requirements

Admin:
- Delete blogs
- Delete comments
- Ban accounts
- Ability to search users by name and username
- Search for blog posts
- View user reports on usage
- Interact with dark/light mode

Registered:
- Able to login and logout using username and password 
- Create blogs and add tags (i.e category)
- Like, comment, save and share others posts
- Follow other users
- Customize their profile page
- Search for blog posts
- Interact with dark/light mode

Unregistered Users:
- View blog posts
- Create account using their email and password
- Share blogs 

## Functional Requirements
Authentication:
- Users must be able to login and logout successfully. 
- Passwords must be stored securely.
- Once a user or admin is logged in, “create account” should no longer be displayed. Only logout option should be displayed

Interactive elements:
- Comments, drafts, user’s posts on their profile page, saved posts will be shown in a threaded format with the latest comment appearing first. 
- Each post will feature a like button that increases the like count, which will be used to determine whether the post has the potential to appear in the trending section.

Admin :
- Comments, drafts, user’s posts on their profile page, saved posts will be shown in a threaded format with the latest comment appearing first. 
- Each post will feature a like button that increases the like count, which will be used to determine whether the post has the potential to appear in the trending section.
- Security and Data Protection:  
- All user’s posts and comments will be validated from both client-side (using JavaScript) and server-side (using PHP) to prevent malicious data from being stored.

## Design document
1. The web page will have the option to sign in on the bottom of sidebar for the users in the form of a button labeled “sign in”. 
2. In the sign in page, there will be an option to create account if user is unregistered
3. Unregistered users can still browse trending and tagged posts. They can navigate to the left sidebar which has different options to interact with the platform. However they cannot like posts, make comments, or save posts.
4. Explore Tags: Browse based on the categories
5. Recent: All the recent posts created by users of this platform
6. Trending: Blog posts with more likes will be displayed higher in the list along with their creators’s username.
7. Make post: only available to the logged in users
8. View Account: only available to logged in users
   - Button is replaced by “Sign in” button when user not logged in/not registered
10. Once a registered user is logged in, they can navigate to the sidebar option called “Make post” on the left.  After clicking on that button, they can add title, add content of the blog, can make attachments, style the writing using bold and italics, and have an option to make it as a draft to edit it later or can post it right away. 
11. To like, comment, and share the blog post, they can click on the desired post and those options will be visible to the right side of the post. 
Logged in users can view their own posts, drafts, saved blogs by navigating to the “View account” option located on the bottom left side of the sidebar. 

