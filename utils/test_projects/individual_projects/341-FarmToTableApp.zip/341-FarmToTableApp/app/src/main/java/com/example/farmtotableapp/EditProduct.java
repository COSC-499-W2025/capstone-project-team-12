package com.example.farmtotableapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;

public class EditProduct extends AppCompatActivity {

    private EditText editName, editDescription, editPrice, editSupply;
    private Spinner typeSpinner;
    private Button buttonSaveProduct, backButton, deleteProdButton;
    private DatabaseReference databaseReference;
    private String productId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_product);

        productId = getIntent().getStringExtra("productId");

        if (productId == null) {
            Toast.makeText(this, "Error: missing Product ID!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        databaseReference = FirebaseDatabase.getInstance().getReference("products");

        editName = findViewById(R.id.editProdName);
        editDescription = findViewById(R.id.editDescription);
        editPrice = findViewById(R.id.editPrice);
        editSupply = findViewById(R.id.editSupply);
        typeSpinner = findViewById(R.id.editTypeSpinner);
        buttonSaveProduct = findViewById(R.id.applyChangesButton);
        backButton = findViewById(R.id.backButton);
        deleteProdButton = findViewById(R.id.deleteButton);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.product_types, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        typeSpinner.setAdapter(adapter);

        loadProductData();

        buttonSaveProduct.setOnClickListener(v -> updateProductInDatabase());
        deleteProdButton.setOnClickListener(v -> deleteProductInDatabase());

        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(EditProduct.this, ManageProduct.class);
            startActivity(intent);
            finish();
        });
    }

    private void deleteProductInDatabase() {
        databaseReference.child(productId).removeValue()
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(EditProduct.this, "Product Deleted Successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(EditProduct.this, ManageProduct.class);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(EditProduct.this, "Could not delete product", Toast.LENGTH_SHORT).show();
                });
    }

    private void loadProductData() {
        databaseReference.child(productId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Product product = dataSnapshot.getValue(Product.class);
                if (product != null) {
                    editName.setText(product.getName());
                    editDescription.setText(product.getDescription());
                    editPrice.setText(String.valueOf(product.getPrice()));
                    editSupply.setText(String.valueOf(product.getSupply()));

                    ArrayAdapter<CharSequence> adapter = (ArrayAdapter<CharSequence>) typeSpinner.getAdapter();
                    int position = adapter.getPosition(product.getType());
                    typeSpinner.setSelection(position);
                } else {
                    Toast.makeText(EditProduct.this, "Product not found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(EditProduct.this, "Error loading product data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateProductInDatabase() {
        String name = editName.getText().toString().trim();
        String description = editDescription.getText().toString().trim();
        String priceStr = editPrice.getText().toString().trim();
        String supplyStr = editSupply.getText().toString().trim();
        String type = typeSpinner.getSelectedItem().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(description) || TextUtils.isEmpty(priceStr) ||
                TextUtils.isEmpty(supplyStr) || TextUtils.isEmpty(type)) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        double price = Double.parseDouble(priceStr);
        int supply = Integer.parseInt(supplyStr);

        Product updatedProduct = new Product(productId, name, description, supply, price, type);
        databaseReference.child(productId).setValue(updatedProduct)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(EditProduct.this, "Product Updated Successfully", Toast.LENGTH_SHORT).show();
                    finish();
                })
                .addOnFailureListener(e -> Toast.makeText(EditProduct.this, "Product Update Failed", Toast.LENGTH_SHORT).show());
    }
}
