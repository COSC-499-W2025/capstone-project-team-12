package com.example.farmtotableapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddProduct extends AppCompatActivity {

    private EditText editTextProductName, editTextProductDescription, editTextProductPrice, editTextProductSupply;
    private Spinner typeSpinner;
    private Button buttonSaveProduct, backButton;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        databaseReference = FirebaseDatabase.getInstance().getReference("products");

        editTextProductName = findViewById(R.id.editProdName);
        editTextProductSupply = findViewById(R.id.editSupply);
        typeSpinner = findViewById(R.id.editTypeSpinner);
        editTextProductPrice = findViewById(R.id.editPrice);
        editTextProductDescription = findViewById(R.id.editDescription);
        buttonSaveProduct = findViewById(R.id.confirmButton);
        backButton = findViewById(R.id.backButton);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.product_types, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        typeSpinner.setAdapter(adapter);

        buttonSaveProduct.setOnClickListener(v -> {
                saveProductToDatabase();
        });

        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(AddProduct.this, ManageProduct.class);
            startActivity(intent);
            finish();
        });
    }

    private void saveProductToDatabase() {
        String name = editTextProductName.getText().toString().trim();
        String supply = editTextProductSupply.getText().toString().trim();
        String type = typeSpinner.getSelectedItem().toString();
        String price = editTextProductPrice.getText().toString().trim();
        String description = editTextProductDescription.getText().toString().trim();

        if (name.isEmpty() || description.isEmpty() || price.isEmpty() || supply.isEmpty() || type.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        String productId = databaseReference.push().getKey();
        Product newProduct = new Product(productId, name, description, Integer.parseInt(supply), Double.parseDouble(price), type);
        databaseReference.child(productId).setValue(newProduct)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(AddProduct.this, "Product added successfully!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(AddProduct.this, ManageProduct.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(AddProduct.this, "Failed to add product: " + e.getMessage(), Toast.LENGTH_SHORT).show());

    }
}
