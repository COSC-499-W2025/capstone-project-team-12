package com.example.farmtotableapp;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class time_dialog_box extends Dialog {
    private OnTimeSelectedListener listener;

    public interface OnTimeSelectedListener {
        void onTimeSelected(String time);
    }

    public time_dialog_box(Context context, OnTimeSelectedListener listener) {
        super(context);
        this.listener = listener;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_dialog_box);

        Button btn900 = findViewById(R.id.button900);
        Button btn1130 = findViewById(R.id.button1130);
        Button btn330 = findViewById(R.id.button330);
        Button btn100 = findViewById(R.id.button100);

        View.OnClickListener buttonClickListener = v -> {
            Button clickedButton = (Button) v;
            String selectedTime = clickedButton.getText().toString();
            if (listener != null) {
                listener.onTimeSelected(selectedTime);
            }
            dismiss();
        };

        btn900.setOnClickListener(buttonClickListener);
        btn1130.setOnClickListener(buttonClickListener);
        btn330.setOnClickListener(buttonClickListener);
        btn100.setOnClickListener(buttonClickListener);
    }
}