package com.example.farmtotableapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class FarmInventory extends AppCompatActivity {
    private ImageView navigateToInventory, navigateToCheckout, header_background, header_background_2; //todo: to checkout

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farm_inventory);

        //views
        header_background = findViewById(R.id.header_background);       //View Farm
        header_background_2 = findViewById(R.id.header_background2);    //View Product
        navigateToCheckout = findViewById(R.id.navigate_to_checkout);   //Cart screen (magnifying glass icon)
        navigateToInventory = findViewById(R.id.navigate_to_manage);    //For farmers to ManageProduct (profile icon)


        //navigate to ViewFarm
        header_background.setOnClickListener(v -> {
            Intent intent = new Intent(FarmInventory.this, ViewFarm.class);
            startActivity(intent);
        });
        //navigate to ViewProduct
        header_background_2.setOnClickListener(v -> {
            Intent intent = new Intent(FarmInventory.this, ViewProduct.class);
            startActivity(intent);
        });
        //user selects the shopping cart, navigates to ManageProduct
        navigateToInventory.setOnClickListener(v -> {
//            Toast.makeText(FarmInventory.this, "Navigating to Inventory Management", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(FarmInventory.this, ManageProduct.class);
            startActivity(intent);
        });
        //navigate to cart screen
        navigateToCheckout.setOnClickListener(v -> {
            Intent intent = new Intent(FarmInventory.this, Cart.class);
            startActivity(intent);
        });
    }
}

