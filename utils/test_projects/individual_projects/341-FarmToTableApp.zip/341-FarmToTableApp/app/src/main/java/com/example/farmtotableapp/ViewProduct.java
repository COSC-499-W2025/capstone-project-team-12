package com.example.farmtotableapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class ViewProduct extends AppCompatActivity {
    private AutoCompleteTextView searchCategory;
    private Button backButton;
    private View headerProduceView, headerMeatsView, headerDairyView, headerSeafoodView, headerOtherView, proceedView;

    private ImageView produceIcon, meatsIcon, dairyIcon, seafoodIcon, navigateToInventory, otherIcon, proceedIcon;
    private String[] categories = {"Produce", "Meats", "Dairy", "Seafood", "Other", "Proceed"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activtiy_view_product);

        //Buttons
        backButton = findViewById(R.id.backButton);

        headerProduceView = findViewById(R.id.header_produce_view);
        produceIcon = findViewById(R.id.produce_icon);

        headerMeatsView = findViewById(R.id.header_meats_view);
        meatsIcon = findViewById(R.id.meats_icon);

        headerDairyView = findViewById(R.id.header_dairy_view);
        dairyIcon = findViewById(R.id.dairy_icon);

        headerSeafoodView = findViewById(R.id.header_seafood_view);
        seafoodIcon = findViewById(R.id.seafood_icon);

        headerOtherView = findViewById(R.id.header_other_view);
        otherIcon = findViewById(R.id.other_icon);

        proceedView = findViewById(R.id.header_proceed_view);
        proceedIcon = findViewById(R.id.proceed_icon);

        // Retrieve totals from SharedPreferences
        SharedPreferences cartPreferences = getSharedPreferences("CartData", MODE_PRIVATE);
        int totalQuantity = cartPreferences.getInt("totalQuantity", 0);
        float totalPrice = cartPreferences.getFloat("totalPrice", 0.0f);


        //go to ManageProduct class (test)
        navigateToInventory = findViewById(R.id.navigate_to_inventory);
        navigateToInventory.setOnClickListener(v -> {
            Toast.makeText(ViewProduct.this, "Navigating to Inventory Management", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(ViewProduct.this, ManageProduct.class);
            startActivity(intent);
        });

        //search category
        searchCategory = findViewById(R.id.search_category);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, categories);
        searchCategory.setAdapter(adapter);
        searchCategory.setOnItemClickListener((parent, view, position, id) -> {
            String selectedCategory = parent.getItemAtPosition(position).toString();
            handleCategorySelection(selectedCategory);
        });

        //user selects the shopping cart, navigates to inventory where they can manage their items
        navigateToInventory.setOnClickListener(v -> {
            Toast.makeText(ViewProduct.this, "Navigating to Inventory Management", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(ViewProduct.this, ManageProduct.class);
            startActivity(intent);
        });

        //return to farmInventory
        backButton.setOnClickListener(v -> finish());

        //produce navigation
        headerProduceView.setOnClickListener(v -> {
            Intent intent = new Intent(ViewProduct.this, Produce.class);
            startActivity(intent);
        });
        produceIcon.setOnClickListener(v -> {
            Intent intent = new Intent(ViewProduct.this, Produce.class);
            startActivity(intent);
        });

        //meats navigation
        headerMeatsView.setOnClickListener(v -> {
            Intent intent = new Intent(ViewProduct.this, Meats.class);
            startActivity(intent);
        });
        meatsIcon.setOnClickListener(v -> {
            Intent intent = new Intent(ViewProduct.this, Meats.class);
            startActivity(intent);
        });

        //dairy navigation
        headerDairyView.setOnClickListener(v -> {
            Intent intent = new Intent(ViewProduct.this, Dairy.class);
            startActivity(intent);
        });
        dairyIcon.setOnClickListener(v -> {
            Intent intent = new Intent(ViewProduct.this, Dairy.class);
            startActivity(intent);
        });

        //seafood navigation
        headerSeafoodView.setOnClickListener(v -> {
            Intent intent = new Intent(ViewProduct.this, Seafood.class);
            startActivity(intent);
        });
        seafoodIcon.setOnClickListener(v -> {
            Intent intent = new Intent(ViewProduct.this, Seafood.class);
            startActivity(intent);
        });
        //seafood navigation
        headerOtherView.setOnClickListener(v -> {
            Intent intent = new Intent(ViewProduct.this, Other.class);
            startActivity(intent);
        });
        otherIcon.setOnClickListener(v -> {
            Intent intent = new Intent(ViewProduct.this, Other.class);
            startActivity(intent);
        });

        //proceed to select location
        proceedView.setOnClickListener(v -> {
            Intent intent = new Intent(ViewProduct.this, meetup_location.class);
            intent.putExtra("totalQuantity", totalQuantity);
            intent.putExtra("totalPrice", totalPrice);
            startActivity(intent);
        });
        proceedIcon.setOnClickListener(v -> {
            Intent intent = new Intent(ViewProduct.this, meetup_location.class);
            intent.putExtra("totalQuantity", totalQuantity);
            intent.putExtra("totalPrice", totalPrice);
            startActivity(intent);
        });
    }
    //autofill once result is found, redirect to new page
    private void handleCategorySelection(String category) {
        Intent intent;
        switch (category) {
            case "Produce":
                intent = new Intent(ViewProduct.this, Produce.class);
                break;
            case "Meats":
                intent = new Intent(ViewProduct.this, Meats.class);
                break;
            case "Dairy":
                intent = new Intent(ViewProduct.this, Dairy.class);
                break;
            case "Seafood":
                intent = new Intent(ViewProduct.this, Seafood.class);
                break;
            case "Other":
                intent = new Intent(ViewProduct.this, Other.class);
                break;
            default:
                return;
        }
        startActivity(intent);
    }
}
