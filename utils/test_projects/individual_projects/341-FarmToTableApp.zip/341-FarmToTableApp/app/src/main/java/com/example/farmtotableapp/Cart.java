package com.example.farmtotableapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Cart extends AppCompatActivity {

    private TextView totalQuantityTextView, totalPriceTextView;
    private Button backButton, homeButton, clearCartButton, proceedToCheckout;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        totalQuantityTextView = findViewById(R.id.totalQuantityTextView);
        totalPriceTextView = findViewById(R.id.totalPriceTextView);
        backButton = findViewById(R.id.backButton);
        homeButton = findViewById(R.id.homeButton);
        clearCartButton = findViewById(R.id.clearButtonForTesting);
        proceedToCheckout = findViewById(R.id.proceed_to_checkout_cart);

        int totalCount = 0;
        float totalPrice = 0.0f;

        //produce
        SharedPreferences producePreferences = getSharedPreferences("ProduceData", MODE_PRIVATE);
        for (int i = 0; i < 5; i++) {
            int count = producePreferences.getInt("count" + (i + 1), 0);
            float price = producePreferences.getFloat("price" + (i + 1), 0.0f);
            totalCount += count;
            totalPrice += price * count;
        }

        //dairy
        SharedPreferences dairyPreferences = getSharedPreferences("DairyData", MODE_PRIVATE);
        for (int i = 0; i < 5; i++) {
            int count = dairyPreferences.getInt("count" + (i + 1), 0);
            float price = dairyPreferences.getFloat("price" + (i + 1), 0.0f);
            totalCount += count;
            totalPrice += price * count;
        }

        //meats
        SharedPreferences meatsPreferences = getSharedPreferences("MeatsData", MODE_PRIVATE);
        for (int i = 0; i < 5; i++) {
            int count = meatsPreferences.getInt("count" + (i + 1), 0);
            float price = meatsPreferences.getFloat("price" + (i + 1), 0.0f);
            totalCount += count;
            totalPrice += price * count;
        }

        //seafood
        SharedPreferences seafoodPreferences = getSharedPreferences("SeafoodData", MODE_PRIVATE);
        for (int i = 0; i < 5; i++) {
            int count = seafoodPreferences.getInt("count" + (i + 1), 0);
            float price = seafoodPreferences.getFloat("price" + (i + 1), 0.0f);
            totalCount += count;
            totalPrice += price * count;
        }

        //other
        SharedPreferences otherPreferences = getSharedPreferences("OtherData", MODE_PRIVATE);
        for (int i = 0; i < 4; i++) {
            int count = otherPreferences.getInt("count" + (i + 1), 0);
            float price = otherPreferences.getFloat("price" + (i + 1), 0.0f);
            totalCount += count;
            totalPrice += price * count;
        }

        //save the cart data
        SharedPreferences cartPreferences = getSharedPreferences("CartData", MODE_PRIVATE);
        SharedPreferences.Editor editor = cartPreferences.edit();
        editor.putInt("totalQuantity", totalCount);
        editor.putFloat("totalPrice", totalPrice);
        editor.apply();

        totalQuantityTextView.setText("Total Quantity: " + totalCount);
        totalPriceTextView.setText("Total Price: $" + String.format("%.2f", totalPrice));

        //Button to navigate back (previous screen)
        backButton.setOnClickListener(v -> {
            Toast.makeText(Cart.this, "Navigating back", Toast.LENGTH_SHORT).show();
            finish();
        });

        //Button to navigate home
        homeButton.setOnClickListener(v -> {
            Toast.makeText(Cart.this, "Navigating to Home", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(Cart.this, FarmInventory.class);
            startActivity(i);
        });

        //Button to clear cart contents
        clearCartButton.setOnClickListener(v -> {
            //clear all SharedPreferences that were saved (reset quantity & price totals)
            clearCartData("ProduceData");
            clearCartData("DairyData");
            clearCartData("MeatsData");
            clearCartData("SeafoodData");
            clearCartData("OtherData");
            clearCartData("CartData");
            totalQuantityTextView.setText("Total Quantity: 0");
            totalPriceTextView.setText("Total Price: $0.00");
//            Toast.makeText(Cart.this, "Cart cleared!", Toast.LENGTH_SHORT).show();
        });

        //head to confirmation page
        int finalTotalCount = totalCount;
        float finalTotalPrice = totalPrice;
        proceedToCheckout.setOnClickListener(v -> {
            Intent intent = new Intent(Cart.this, meetupDetails.class);
            intent.putExtra("totalQuantity", finalTotalCount);
            intent.putExtra("totalPrice", finalTotalPrice);
            startActivity(intent);
        });

    }
    private void clearCartData(String prefName) {
        SharedPreferences preferences = getSharedPreferences(prefName, MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();
        editor.clear();
        editor.apply();
    }
}
