package com.example.farmtotableapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class meetupDetails extends AppCompatActivity {

    TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_meetup_details);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

//        SharedPreferences cartPrefs = getSharedPreferences("CartData", MODE_PRIVATE);
//        int totalQuantity = cartPrefs.getInt("totalQuantity", 0);
//        float totalPrice = cartPrefs.getFloat("totalPrice", 0.0f);

        Intent intent = getIntent();
        String date = intent.getStringExtra("date");
        String time = intent.getStringExtra("time");
        String location = intent.getStringExtra("location");

        resultText = findViewById(R.id.resultText);
        resultText.setText("Confirmed! \nMeeting details: \n Date: " + date + "\n Time: " + time + "\nLocation: " + location +
                "\n\nPayment Details\nMethod: e-transfer\nEmail: farmer@farm.com\nMade to: Joe Farmer");
//                "\nTotal Items: " + totalQuantity + " items in cart" + "\nTotal Price: $" + String.format("%.2f", totalPrice));

        Button button = findViewById(R.id.button);
        button.setOnClickListener(v -> {
            Intent intent1 = new Intent(this, FarmInventory.class);
            intent1.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent1);
            finish();
        });

    }
}