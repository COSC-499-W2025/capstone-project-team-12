package com.example.farmtotableapp;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import androidx.fragment.app.FragmentActivity;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.farmtotableapp.databinding.ActivityMeetupLocationBinding;

public class meetup_location extends FragmentActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener {
    private GoogleMap mMap;
    private ActivityMeetupLocationBinding binding;
    // Theoretical starting point (e.g., user's location)
    private final LatLng startPoint = new LatLng(49.8851, -119.4960); // West Kelowna


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMeetupLocationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        mMap.setOnMarkerClickListener(this);

        // Add markers with calculated distances
        addMarkerWithDistance(new LatLng(49.8890332608925, -119.42518697409977), "Walmart", "1555 Banks Rd");
        addMarkerWithDistance(new LatLng(49.9394, -119.3948), "UBCO Campus", "3333 University Way");
        addMarkerWithDistance(new LatLng(50.0537, -119.4106), "Lake Country", "456 Lake Road");

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(49.8890332608925, -119.42518697409977), 11));
    }

    private void addMarkerWithDistance(LatLng position, String title, String address) {
        float[] results = new float[1];
        Location.distanceBetween(
                startPoint.latitude, startPoint.longitude,
                position.latitude, position.longitude,
                results
        );

        // Convert meters to kilometers and round to 1 decimal
        float distanceKm = Math.round(results[0] / 100.0f) / 10.0f;

        mMap.addMarker(new MarkerOptions()
                .position(position)
                .title(title)
                .snippet(address + " • " + distanceKm + "km away"));
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        String[] parts = marker.getSnippet().split(" • ");
        String address = parts[0];
        String distance = parts[1];

        Intent intent = new Intent(this, locationConfirmation.class);
        intent.putExtra("location", marker.getTitle());
        intent.putExtra("address", address);
        intent.putExtra("distance", distance);
        startActivity(intent);
        return true;
    }
}