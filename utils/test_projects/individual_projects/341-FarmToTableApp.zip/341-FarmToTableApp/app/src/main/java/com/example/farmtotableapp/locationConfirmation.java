package com.example.farmtotableapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class locationConfirmation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_location_confirmation);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent intent = getIntent();
        String location = intent.getStringExtra("location");
        String address = intent.getStringExtra("address");
        String distance = intent.getStringExtra("distance");

        TextView confirmText = findViewById(R.id.confirmText);
        confirmText.setText("Selected Location: \n" + location + "\n" + address + "\n" + distance + " away");

        Button confirmButton = findViewById(R.id.confirmButton);
        Button backButton = findViewById(R.id.cancelButton);

        confirmButton.setOnClickListener(v -> {
            Intent intent1 = new Intent(this, SelectMeetup.class);
            intent1.putExtra("location", location);
            startActivity(intent1);
        });

        backButton.setOnClickListener(v -> {
            finish();
        });
    }
}