package com.example.farmtotableapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SearchByProducts extends AppCompatActivity {

    SearchView svSearch;

    Button btnBack, btnProduce, btnMeats, btnDairy, btnSeafood, btnHome, btnOther;

    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_search_by_product);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        databaseReference = FirebaseDatabase.getInstance().getReference();

        svSearch = findViewById(R.id.inventorySearch);

        btnBack = findViewById(R.id.btnBack);
        btnProduce = findViewById(R.id.btnProduce);
        btnMeats = findViewById(R.id.btnMeats);
        btnDairy = findViewById(R.id.btnDairy);
        btnSeafood = findViewById(R.id.btnSeafood);
        btnHome = findViewById(R.id.btnHome);
        btnOther = findViewById(R.id.btnOther);

        svSearch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                if(!query.trim().isEmpty()) {
                    searchProducts(query.trim());
                } else {
                    Toast.makeText(SearchByProducts.this, "Please enter a search term", Toast.LENGTH_SHORT).show();
                }
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });

        btnBack.setOnClickListener(v -> finish());

        btnProduce.setOnClickListener(v -> navigateToBrowse("Produce"));
        btnMeats.setOnClickListener(v -> navigateToBrowse("Meat"));
        btnDairy.setOnClickListener(v -> navigateToBrowse("Dairy"));
        btnSeafood.setOnClickListener(v -> navigateToBrowse("Seafood"));
        btnHome.setOnClickListener(v -> navigateToBrowse("Home"));
        btnOther.setOnClickListener(v -> navigateToBrowse("Other"));
    }

    private void searchProducts(String searchQuery) {
        databaseReference.child("products").orderByChild("name")
                .startAt(searchQuery)
                .endAt(searchQuery + "\uf8ff")
                .limitToFirst(1)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists()) {
                            for (DataSnapshot data : snapshot.getChildren()) {
                                Product product = data.getValue(Product.class);
                                if(product != null && product.getName().equalsIgnoreCase(searchQuery)) {
                                    Intent intent = new Intent(SearchByProducts.this, BrowseByProduct.class);
                                    intent.putExtra("category", product.getType());
                                    intent.putExtra("searchQuery", searchQuery);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                                    startActivity(intent);
                                    return;
                                }
                            }
                        } else {
                            Toast.makeText(SearchByProducts.this, "No products found matching '" + searchQuery + "'", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(SearchByProducts.this, "Search Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void navigateToBrowse(String category) {
        Intent intent = new Intent(SearchByProducts.this, BrowseByProduct.class);
        intent.putExtra("category", category);
        startActivity(intent);
    }
}