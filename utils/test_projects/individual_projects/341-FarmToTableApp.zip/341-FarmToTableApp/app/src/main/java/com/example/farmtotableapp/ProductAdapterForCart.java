package com.example.farmtotableapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ProductAdapterForCart extends RecyclerView.Adapter<ProductAdapterForCart.ProductViewHolder> {
    private List<Product> productList;

    private List<Product> filteredList;

    private Context context;

    public ProductAdapterForCart(Context context, List<Product> productList) {
        this.context = context;
        this.productList = productList;
        this.filteredList = new ArrayList<>(productList);
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_search_card, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        Product product = filteredList.get(position);

        holder.productName.setText(product.getName());
        holder.productQuantity.setText("Available Quantity: " + product.getSupply());
        holder.productPrice.setText(String.format("$%.2f", product.getPrice()));
        holder.farmName.setText("Farm Name");
        holder.productImage.setImageResource(getCategoryIcon(product.getType()));

        holder.addToCartButton.setOnClickListener(v -> {
            addToCart(product);
        });
    }

    @Override
    public int getItemCount() {
        return filteredList.size();
    }

    public static class ProductViewHolder extends RecyclerView.ViewHolder {
        ImageView productImage;
        TextView productName, productQuantity, productPrice, farmName;
        Button addToCartButton;

        public ProductViewHolder(View itemView) {
            super(itemView);
            productImage = itemView.findViewById(R.id.ivProductImage);
            productName = itemView.findViewById(R.id.tvProductName);
            productQuantity = itemView.findViewById(R.id.tvQuantity);
            productPrice = itemView.findViewById(R.id.tvPrice);
            farmName = itemView.findViewById(R.id.tvFarmName);
            addToCartButton = itemView.findViewById(R.id.btnAddtoCart);
        }
    }

    private void addToCart(Product product) {
        // To Do
        Toast.makeText(context, product.getName() + " added to cart!", Toast.LENGTH_SHORT).show();
    }

    private int getCategoryIcon(String category) {
        if (category == null) return R.drawable.other_icon;

        switch (category) {
            case "Produce":
                return R.drawable.produce_icon;
            case "Meat":
                return R.drawable.meats_icon;
            case "Dairy":
                return R.drawable.dairy_icon;
            case "Seafood":
                return R.drawable.seafood_icon;
            case "Home":
                return R.drawable.home_icon2;
            case "Other":
            default:
                return R.drawable.other_icon;
        }
    }

    public void filter(String query) {
        filteredList.clear();
        if (query.isEmpty()) {
            filteredList.addAll(productList);
        } else {
            for (Product product : productList) {
                if (product.getName().toLowerCase().contains(query.toLowerCase())) {
                    filteredList.add(product);
                }
            }
        }
        notifyDataSetChanged();
    }

    public void updateProductList(List<Product> newProductList) {
        this.productList = new ArrayList<>(newProductList);
        this.filteredList = new ArrayList<>(newProductList);
        notifyDataSetChanged();
    }
}

