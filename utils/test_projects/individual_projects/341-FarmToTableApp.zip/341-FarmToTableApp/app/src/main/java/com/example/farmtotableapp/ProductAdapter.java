package com.example.farmtotableapp;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ProductViewHolder> {

    private List<Product> productList;
    private Context context;

    public ProductAdapter(Context context, List<Product> productList) {
        this.context = context;
        this.productList = productList;
    }

    @NonNull
    @Override
    public ProductViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_card, parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductViewHolder holder, int position) {
        Product product = productList.get(position);

        holder.productName.setText(product.getName());
        holder.productDescription.setText(product.getDescription());
        holder.productPrice.setText(String.format("Price: $%.2f", product.getPrice()));
        holder.productSupply.setText(String.format("Supply: %d", product.getSupply()));
        holder.productType.setText("Type: " + product.getType());

        holder.manageButton.setOnClickListener(v -> {
            String productId = product.getId();
            Log.d("ProductAdapter", "Product ID being passed: " + productId);
            Intent intent = new Intent(context, EditProduct.class);
            intent.putExtra("productId", productId);
            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public static class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView productName, productDescription, productPrice, productSupply, productType;
        Button manageButton;

        public ProductViewHolder(View itemView) {
            super(itemView);
            productName = itemView.findViewById(R.id.product_name);
            productDescription = itemView.findViewById(R.id.product_description);
            productPrice = itemView.findViewById(R.id.product_price);
            productSupply = itemView.findViewById(R.id.product_supply);
            productType = itemView.findViewById(R.id.product_type);
            manageButton = itemView.findViewById(R.id.manage_product_button);
        }
    }
}