package com.example.farmtotableapp;

import android.os.Bundle;
import android.text.TextWatcher;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SearchView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class ViewFarm extends AppCompatActivity {

    private TextView infoFarm1, infoFarm2, infoFarm3;
    private SearchView searchFarm;
    private String[] farmNames = {"Okanagan Farm", "Sunrise Farms", "Oak Valley Farms"};
    private LinearLayout[] farmLayouts ;
    private Button backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_farm);

        infoFarm1 = findViewById(R.id.info_farm1);
        infoFarm2 = findViewById(R.id.info_farm2);
        infoFarm3 = findViewById(R.id.info_farm3);
        searchFarm = findViewById(R.id.search_category);
        backButton = findViewById(R.id.backButton);

        LinearLayout layout1 = findViewById(R.id.layout1);
        LinearLayout layout2 = findViewById(R.id.layout2);
        LinearLayout layout3 = findViewById(R.id.layout3);

        farmLayouts = new LinearLayout[]{layout1, layout2, layout3};

        //back Button
        backButton.setOnClickListener(v -> finish());

        //info dialog for Farm 1
        infoFarm1.setOnClickListener(v -> showFarmInfoDialog(
                "Okanagan Farm",
                "Dedicated to sustainable farming and organic practices, " +
                        "they offer fresh, local products for the community. " +
                        "\n\nOur Products: Apples, Carrots, Ground Beef, Milk, Cheese, Eggs, Chicken"
        ));
        infoFarm2.setOnClickListener(v -> showFarmInfoDialog(
                "Sunrise Farms",
                "Dedicated to sustainable farming and organic practices, " +
                        "they offer fresh, local products for the community. " +
                        "\n\nOur Products: Apples, Carrots, Ground Beef, Milk, Cheese, Eggs, Chicken"
        ));
        infoFarm3.setOnClickListener(v -> showFarmInfoDialog(
                "Oak Valley Farms",
                "Dedicated to sustainable farming and organic practices, " +
                        " they offer fresh, local products for the community. " +
                        "\n\nOur Products: Apples, Carrots, Ground Beef, Milk, Cheese, Eggs, Chicken"
        ));
        searchFarm.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                filterFarms(newText);
                return true;
            }
        });
    }
    private void showFarmInfoDialog(String farmName, String description) {
        AlertDialog.Builder builder = new AlertDialog.Builder(ViewFarm.this);
        builder.setTitle(farmName);
        builder.setMessage(description);
        builder.setPositiveButton("Close", (dialog, which) -> dialog.dismiss());
        builder.show();
    }
    private void filterFarms(String query) {
        String lowerQuery = query.toLowerCase();
        for (int i = 0; i < farmNames.length; i++) {
            if (farmNames[i].toLowerCase().contains(lowerQuery)) {
                farmLayouts[i].setVisibility(View.VISIBLE);
            } else {
                farmLayouts[i].setVisibility(View.GONE);
            }
        }
    }
}
