package com.example.farmtotableapp;

import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Continue extends AppCompatActivity {

    //continue to select community drop off point / pick up location & then order confirmation
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produce);

    }
}
