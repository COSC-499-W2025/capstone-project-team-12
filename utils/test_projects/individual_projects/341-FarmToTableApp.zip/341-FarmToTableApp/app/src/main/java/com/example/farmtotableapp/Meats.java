package com.example.farmtotableapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class Meats extends AppCompatActivity {
    private Button button_to_filter, button_to_save, button_to_cart, backButton, addButton1, addButton2, addButton3, addButton4, addButton5, removeButton1, removeButton2, removeButton3, removeButton4, removeButton5;
    private TextView quantity1, quantity2, quantity3, quantity4, quantity5, price_meats, quantity_meats;
    private int totalCount = 0;
    private float totalPrice = 0.0f;
    private SearchView searchViewMeats;
    private ScrollView scroll_view;
    private LinearLayout linear_layout;
    private String[] meatsItems = {"Chicken Breast", "Ground Beef", "Sausage", "Pork Chops", "Steak"};
    private LinearLayout[] itemLayouts;
    private int[] counts = new int[5];
    private float[] prices = new float[5];
    private boolean[] isOrganic = {true, false, true, false, true};
    private View cartLayout;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meats);

        SharedPreferences sharedPreferences = getSharedPreferences("MeatsData", MODE_PRIVATE);

        for (int i = 0; i < 5; i++) {
            counts[i] = sharedPreferences.getInt("count" + (i + 1), 0);
        }
        prices[0] = sharedPreferences.getFloat("price1", 1.44f);
        prices[1] = sharedPreferences.getFloat("price2", 1.09f);
        prices[2] = sharedPreferences.getFloat("price3", 1.15f);
        prices[3] = sharedPreferences.getFloat("price4", 1.20f);
        prices[4] = sharedPreferences.getFloat("price5", 2.55f);

        totalCount = sharedPreferences.getInt("totalQuantity", 0);
        totalPrice = sharedPreferences.getFloat("totalPrice", 0.0f);
        cartLayout = findViewById(R.id.cart_layout);


        //Buttons
        backButton = findViewById(R.id.backButton);

        button_to_filter = findViewById(R.id.button_to_filter);

        button_to_save = findViewById(R.id.button_to_save);
        button_to_cart = findViewById(R.id.button_to_cart);

        addButton1 = findViewById(R.id.button_add1);
        removeButton1 = findViewById(R.id.button_remove1);
        quantity1 = findViewById(R.id.text_quantity1);

        addButton2 = findViewById(R.id.button_add2);
        removeButton2 = findViewById(R.id.button_remove2);
        quantity2 = findViewById(R.id.text_quantity2);

        addButton3 = findViewById(R.id.button_add3);
        removeButton3 = findViewById(R.id.button_remove3);
        quantity3 = findViewById(R.id.text_quantity3);

        addButton4 = findViewById(R.id.button_add4);
        removeButton4 = findViewById(R.id.button_remove4);
        quantity4 = findViewById(R.id.text_quantity4);

        addButton5 = findViewById(R.id.button_add5);
        removeButton5 = findViewById(R.id.button_remove5);
        quantity5 = findViewById(R.id.text_quantity5);

        quantity_meats = findViewById(R.id.quantity_meats);
        price_meats = findViewById(R.id.price_meats);

        TextView[] altTextViews = new TextView[]{
                findViewById(R.id.altTextView1),
                findViewById(R.id.altTextView2),
                findViewById(R.id.altTextView3),
                findViewById(R.id.altTextView4),
                findViewById(R.id.altTextView5)
        };

        String[] farmNames = {
                "Okanagan Farm",
                "Sunrise Farms",
                "Oak Valley Farms",
                "Sunrise Farms",
                "Sunrise Farms"
        };
        String[] farmDescriptions = {
                "Serving the community for over 50 years with their fresh, organic appples.",
                "Carrots grown from sustainable soil.",
                "Organic potatoes grown in the Okanagan.",
                "Spinach grown in the Okanagan",
                "Ripe and organic tomatoes"
        };
        for (int i = 0; i < altTextViews.length; i++) {
            int index = i;
            altTextViews[i].setOnClickListener(v -> showFarmInfoDialog(farmNames[index], farmDescriptions[index]));
        }

        quantity1.setText(String.valueOf(counts[0]));
        quantity2.setText(String.valueOf(counts[1]));
        quantity3.setText(String.valueOf(counts[2]));
        quantity4.setText(String.valueOf(counts[3]));
        quantity5.setText(String.valueOf(counts[4]));

        updateTotalDisplay();

        setUpQuantityButton(addButton1, removeButton1, quantity1, 0);
        setUpQuantityButton(addButton2, removeButton2, quantity2, 1);
        setUpQuantityButton(addButton3, removeButton3, quantity3, 2);
        setUpQuantityButton(addButton4, removeButton4, quantity4, 3);
        setUpQuantityButton(addButton5, removeButton5, quantity5, 4);

        updateTotalPriceAndQuantity();

        //save progress
        button_to_save.setOnClickListener(v -> {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putInt("totalQuantity", totalCount);
            editor.putFloat("totalPrice", totalPrice);
            for (int i = 0; i < 5; i++) {
                editor.putInt("count" + (i + 1), counts[i]);
            }
            for (int i = 0; i < 5; i++){
                editor.putFloat("price" + (i + 1), prices[i]);
            }
            editor.apply();
            Toast.makeText(Meats.this, "Items saved to cart", Toast.LENGTH_SHORT).show();
        });

        //go to cart button
        button_to_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Meats.this, Cart.class);
                startActivity(intent);
            }
        });

        button_to_filter.setOnClickListener(v -> showFilterDialog());

        // Views
        searchViewMeats = findViewById(R.id.searchViewMeats);
        scroll_view = findViewById(R.id.scroll_view);
        linear_layout = findViewById(R.id.linear_layout);
        itemLayouts = new LinearLayout[]{
                findViewById(R.id.chicken_layout),
                findViewById(R.id.beef_layout),
                findViewById(R.id.sausage_layout),
                findViewById(R.id.pork_layout),
                findViewById(R.id.steak_layout)
        };
        searchViewMeats.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                filterItems(newText);
                return true;
            }
        });
        //return to ViewProduct
        backButton.setOnClickListener(v -> finish());
    }
    private void setUpQuantityButton(Button addButton, Button removeButton, TextView quantityView, final int itemIndex) {
        addButton.setOnClickListener(v -> {
            counts[itemIndex]++;
            quantityView.setText(String.valueOf(counts[itemIndex]));
            updateTotalPriceAndQuantity();
        });

        removeButton.setOnClickListener(v -> {
            if (counts[itemIndex] > 0) {
                counts[itemIndex]--;
                quantityView.setText(String.valueOf(counts[itemIndex]));
                updateTotalPriceAndQuantity();
            }
        });
    }
    private void updateTotalPriceAndQuantity() {
        totalCount = 0;
        totalPrice = 0.0F;
        for (int count : counts) {
            totalCount += count;
        }
        for (int i = 0; i < 5; i++) {
            totalPrice += prices[i] * counts[i];
        }
        updateTotalDisplay();
    }
    private void updateTotalDisplay() {
        quantity_meats.setText(String.format("Total Quantity: %d", totalCount));
        price_meats.setText(String.format("Total Price: $%.2f", totalPrice));
    }
    private void filterItems(String query) {
        String queryLower = query.toLowerCase();
        for (int i = 0; i < meatsItems.length; i++) {
            String itemName = meatsItems[i].toLowerCase();
            if (itemName.contains(queryLower)) {
                itemLayouts[i].setVisibility(View.VISIBLE);
            } else {
                itemLayouts[i].setVisibility(View.GONE);
            }
        }
    }
    private void showFilterDialog() {
        final String[] options = {"Organic Only", "Price: Low to High", "Price: High to Low", "Clear Filters"};
        AlertDialog.Builder builder = new AlertDialog.Builder(Meats.this);
        builder.setTitle("Filter Options");
        builder.setItems(options, (dialog, which) -> {
            switch (which) {
                case 0: //Organic Only
                    applyFilter(1, searchViewMeats.getQuery().toString());
                    break;
                case 1: //Price Low to High
                    applyFilter(2, searchViewMeats.getQuery().toString());
                    break;
                case 2: //Price High to Low
                    applyFilter(3, searchViewMeats.getQuery().toString());
                    break;
                case 3: //Clear Filters
                    searchViewMeats.setQuery("", false);
                    applyFilter(0, "");
                    break;
            }
        });
        builder.create().show();
    }
    private void applyFilter(int filterType, String query) {
        List<Integer> visibleIndexes = new ArrayList<>();

        String queryLower = query.toLowerCase();
        for (int i = 0; i < meatsItems.length; i++) {
            if (meatsItems[i].toLowerCase().contains(queryLower)) {
                visibleIndexes.add(i);
            }
        }
        String toast = "";
        if (filterType == 1) {
            visibleIndexes.removeIf(i -> !isOrganic[i]);
            toast = "Filter applied: Organic Only";
        } else if (filterType == 2) {
            visibleIndexes.sort((i1, i2) -> Float.compare(prices[i1], prices[i2]));
            toast = "Filter applied: Price Low to High";
        } else if (filterType == 3) {
            visibleIndexes.sort((i1, i2) -> Float.compare(prices[i2], prices[i1]));
            toast = "Filter applied: Price High to Low";
        } else {
            toast = "Filters cleared";
        }
        //Remove only product layouts
        for (LinearLayout layout : itemLayouts) {
            linear_layout.removeView(layout);
        }
        //re insert items
        int insertIndex = linear_layout.indexOfChild(cartLayout);
        for (int index : visibleIndexes) {
            linear_layout.addView(itemLayouts[index], insertIndex++);
        }
        Toast.makeText(this, toast, Toast.LENGTH_SHORT).show();
    }

    private void showFarmInfoDialog(String farmName, String description) {
        AlertDialog.Builder builder = new AlertDialog.Builder(Meats.this);
        builder.setTitle(farmName);
        builder.setMessage(description);
        builder.setPositiveButton("Close", (dialog, which) -> dialog.dismiss());
        builder.show();
    }
}
