package com.example.farmtotableapp;

public class Product {
    private String id;
    private String name;
    private String description;
    private int supply;
    private double price;
    private String type;

    public Product() {}

    public Product(String id, String name, String description, int supply, double price, String type) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.supply = supply;
        this.price = price;
        this.type = type;
    }

    public String getId() {return id;}

    public void setId(String id) {this.id = id;}

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getSupply() {
        return supply;
    }

    public void setSupply(int supply) {
        this.supply = supply;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getType() {return type;}

    public void setType(String type) {this.type = type;}
}
