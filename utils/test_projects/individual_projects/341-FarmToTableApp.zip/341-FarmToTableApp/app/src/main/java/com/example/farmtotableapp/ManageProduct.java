package com.example.farmtotableapp;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.RadioGroup;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ManageProduct extends AppCompatActivity {
    Button addProductBtn, filterButton;
    private RecyclerView productRecyclerView;
    private ProductAdapter productAdapter;
    private List<Product> productList;
    private DatabaseReference databaseReference;
    private SearchView searchView;
    private boolean isSearchActive = false;

    private Button backButton; //return to farm inventory

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_product);

        addProductBtn = findViewById(R.id.addProductButton);
        filterButton = findViewById(R.id.filterButton);
        productRecyclerView = findViewById(R.id.productRecyclerView);
        searchView = findViewById(R.id.inventorySearch);
        productRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        productList = new ArrayList<>();

        backButton = findViewById(R.id.backButton);

        productAdapter = new ProductAdapter(this, productList);
        productRecyclerView.setAdapter(productAdapter);

        databaseReference = FirebaseDatabase.getInstance().getReference("products");

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                productList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Product product = snapshot.getValue(Product.class);
                    productList.add(product);
                }

                if (!isSearchActive) {
                    productAdapter = new ProductAdapter(ManageProduct.this, productList);
                    productRecyclerView.setAdapter(productAdapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(ManageProduct.this, "Could not load products", Toast.LENGTH_SHORT).show();
            }
        });

        setupSearchView();

        addProductBtn.setOnClickListener(v -> {
            Intent intent = new Intent(ManageProduct.this, AddProduct.class);
            startActivity(intent);
        });

        filterButton.setOnClickListener(v -> showFilterPopup());

        //return to farm inventory
        backButton.setOnClickListener(v -> {
            Toast.makeText(ManageProduct.this, "Returning to home screen", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(ManageProduct.this, FarmInventory.class);
            startActivity(intent);
        });
    }

    private void setupSearchView() { // for search bar
        searchView.setIconified(true);

        searchView.setQueryHint("Search by product name...");

        searchView.setOnSearchClickListener(v -> {
            isSearchActive = true;
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterProducts(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (isSearchActive && newText != null && !newText.isEmpty()) {
                    filterProducts(newText);
                }
                return true;
            }
        });

        searchView.setOnCloseListener(() -> {
            isSearchActive = false;
            searchView.clearFocus();
            productAdapter = new ProductAdapter(ManageProduct.this, productList);
            productRecyclerView.setAdapter(productAdapter);
            return false;
        });
    }

    private void filterProducts(String query) { // for search bar
        if (query == null || query.trim().isEmpty()) {
            isSearchActive = false;
            productAdapter = new ProductAdapter(ManageProduct.this, productList);
            productRecyclerView.setAdapter(productAdapter);
            return;
        }

        String lowercaseQuery = query.toLowerCase().trim();
        List<Product> filteredList = new ArrayList<>();

        for (Product product : productList) {
            if (product.getName().toLowerCase().contains(lowercaseQuery)) {
                filteredList.add(product);
            }
        }

        productAdapter = new ProductAdapter(ManageProduct.this, filteredList);
        productRecyclerView.setAdapter(productAdapter);

        if (filteredList.isEmpty()) {
            Toast.makeText(this, "No products match your search", Toast.LENGTH_SHORT).show();
        }
    }

    private void showFilterPopup() { // for filter pop up
        View popupView = getLayoutInflater().inflate(R.layout.filter_popup, null);

        PopupWindow popupWindow = new PopupWindow(
                popupView,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                true
        );

        popupWindow.setAnimationStyle(android.R.style.Animation_Dialog);

        popupWindow.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        popupWindow.setElevation(20);

        RadioGroup priceRadioGroup = popupView.findViewById(R.id.priceRadioGroup);
        RadioGroup inventoryRadioGroup = popupView.findViewById(R.id.inventoryRadioGroup);
        Button applyFiltersButton = popupView.findViewById(R.id.applyFiltersButton);

        applyFiltersButton.setOnClickListener(v -> {
            int selectedPriceId = priceRadioGroup.getCheckedRadioButtonId();
            String priceSort = "none";
            if (selectedPriceId == R.id.priceLowToHigh) {
                priceSort = "lowToHigh";
            } else if (selectedPriceId == R.id.priceHighToLow) {
                priceSort = "highToLow";
            }

            int selectedInventoryId = inventoryRadioGroup.getCheckedRadioButtonId();
            String inventorySort = "none";
            if (selectedInventoryId == R.id.inventoryLowToHigh) {
                inventorySort = "lowToHigh";
            } else if (selectedInventoryId == R.id.inventoryHighToLow) {
                inventorySort = "highToLow";
            }

            applyFilters(priceSort, inventorySort);

            popupWindow.dismiss();
        });

        popupWindow.showAtLocation(filterButton, Gravity.CENTER, 0, 0);
    }

    private void applyFilters(String priceSort, String inventorySort) { // sorting for filter popup
        List<Product> filteredList = new ArrayList<>(productList);

        if (priceSort.equals("lowToHigh")) {
            Collections.sort(filteredList, (p1, p2) -> Double.compare(p1.getPrice(), p2.getPrice()));
        } else if (priceSort.equals("highToLow")) {
            Collections.sort(filteredList, (p1, p2) -> Double.compare(p2.getPrice(), p1.getPrice()));
        }

        if (inventorySort.equals("lowToHigh")) {
            Collections.sort(filteredList, (p1, p2) -> Integer.compare(p1.getSupply(), p2.getSupply()));
        } else if (inventorySort.equals("highToLow")) {
            Collections.sort(filteredList, (p1, p2) -> Integer.compare(p2.getSupply(), p1.getSupply()));
        }

        productAdapter = new ProductAdapter(ManageProduct.this, filteredList);
        productRecyclerView.setAdapter(productAdapter);

        Toast.makeText(this, "Filters applied!", Toast.LENGTH_SHORT).show();
    }
}