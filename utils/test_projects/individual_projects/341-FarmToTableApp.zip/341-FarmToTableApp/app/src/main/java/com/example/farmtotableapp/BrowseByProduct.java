package com.example.farmtotableapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class BrowseByProduct extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProductAdapterForCart productAdapter;
    private List<Product> productList;
    private DatabaseReference databaseReference;
    private String selectedCategory, searchQuery;

    private Button btnBack;

    private TextView category;

    private ImageView categoryImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_browse_by_products);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        selectedCategory = getIntent().getStringExtra("category");
        searchQuery = getIntent().getStringExtra("searchQuery");

        category = findViewById(R.id.tvCategory);
        category.setText(selectedCategory);
        categoryImage = findViewById(R.id.ivCategoryImage);
        displayCategoryImage(selectedCategory);

        recyclerView = findViewById(R.id.productRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        productList = new ArrayList<>();
        productAdapter = new ProductAdapterForCart(this, productList);
        recyclerView.setAdapter(productAdapter);

        btnBack = findViewById(R.id.btnBack);

        btnBack.setOnClickListener(v -> finish());

        if(selectedCategory != null) {
            loadProductsByCategory(selectedCategory);
        } else {
            Toast.makeText(this, "No category selected", Toast.LENGTH_SHORT).show();
        }


        SearchView searchView = findViewById(R.id.inventorySearch);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                productAdapter.filter(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                productAdapter.filter(newText);
                return false;
            }
        });

    }

    private void loadProductsByCategory(String category) {
        databaseReference = FirebaseDatabase.getInstance().getReference("products");

        databaseReference.orderByChild("type").equalTo(category)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        List<Product> tempProductList = new ArrayList<>();
                        int count = 0;
                        for (DataSnapshot data : snapshot.getChildren()) {
                            Product product = data.getValue(Product.class);
                            if (product != null) {
                                tempProductList.add(product);
                                count++;
                            }
                        }

                        productAdapter.updateProductList(tempProductList);

                        if(searchQuery != null && !searchQuery.isEmpty()) {
                            productAdapter.filter(searchQuery);
                        }

                        Toast.makeText(BrowseByProduct.this, "Products found: " + count, Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(BrowseByProduct.this, "Failed to load products", Toast.LENGTH_SHORT).show();
                    }
                });
    }


    public void displayCategoryImage(String selectedCategory) {
        switch (selectedCategory) {
            case "Produce":
                categoryImage.setImageResource(R.drawable.produce_icon);
                break;
            case "Meat":
                categoryImage.setImageResource(R.drawable.meats_icon);
                break;
            case "Dairy":
                categoryImage.setImageResource(R.drawable.dairy_icon);
                break;
            case "Seafood":
                categoryImage.setImageResource(R.drawable.seafood_icon);
                break;
            case "Home":
                categoryImage.setImageResource(R.drawable.home_icon2);
                break;
            case "Other":
                categoryImage.setImageResource(R.drawable.other_icon);
                break;
        }
    }


}