package com.example.farmtotableapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FindProducts extends AppCompatActivity {

    private SearchView svSearch;
    private Button btnSearchByFarm, btnSearchByProduct;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_find_products);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        databaseReference = FirebaseDatabase.getInstance().getReference();

        svSearch = findViewById(R.id.inventorySearch);
        btnSearchByFarm = findViewById(R.id.btnSearchByFarm);
        btnSearchByProduct = findViewById(R.id.btnSearchByProduct);


        svSearch.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                if(!query.trim().isEmpty()) {
                    searchInDatabase(query.trim());
                } else {
                    Toast.makeText(FindProducts.this, "Please enter a search term", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });

        btnSearchByFarm.setOnClickListener(v -> {
            Intent intent = new Intent(FindProducts.this, SearchByFarms.class);
            startActivity(intent);
        });

        btnSearchByProduct.setOnClickListener(v -> {
            Intent intent = new Intent(FindProducts.this, SearchByProducts.class);
            startActivity(intent);
        });
    }

    public void searchInDatabase(String searchQuery) {
        databaseReference.child("farms").orderByChild("name").startAt(searchQuery).endAt(searchQuery + "\uf8ff")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists()) {
                            Intent intent = new Intent(FindProducts.this, SearchByFarms.class);
                            intent.putExtra("searchQuery", searchQuery);
                            startActivity(intent);
                            return;
                        }

                        databaseReference.child("products").orderByChild("name").startAt(searchQuery).endAt(searchQuery + "\uf8ff")
                                .addListenerForSingleValueEvent(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        if(snapshot.exists()) {
                                            for (DataSnapshot data : snapshot.getChildren()) {
                                                Product product = data.getValue(Product.class);
                                                if(product != null && product.getName().equalsIgnoreCase(searchQuery)) {
                                                    Intent intent = new Intent(FindProducts.this, BrowseByProduct.class);
                                                    intent.putExtra("category", product.getType());
                                                    intent.putExtra("searchQuery", searchQuery);
                                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                                                    startActivity(intent);
                                                    return;
                                                }
                                            }
                                        } else {
                                            Toast.makeText(FindProducts.this, "No farms or products found matching '" + searchQuery + "'", Toast.LENGTH_SHORT).show();
                                        }
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {
                                        Toast.makeText(FindProducts.this, "Search error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                });

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Toast.makeText(FindProducts.this, "Search error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

    }
}