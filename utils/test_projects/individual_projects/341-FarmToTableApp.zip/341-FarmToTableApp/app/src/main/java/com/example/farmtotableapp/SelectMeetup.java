package com.example.farmtotableapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;

public class SelectMeetup extends AppCompatActivity {

    private static final int TIME_PICKER_REQUEST = 1;
    private String selectedDate;
    private String selectedTime;
    private String location;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_select_meetup);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        location = getIntent().getStringExtra("location");
        int totalQuantity = getIntent().getIntExtra("totalQuantity", 0);
        float totalPrice = getIntent().getFloatExtra("totalPrice", 0.0f);

        CalendarView calendarView = findViewById(R.id.calendarView);
        calendarView.setMinDate(System.currentTimeMillis() - 1000); // Set minimum date to current date
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            Calendar selectedCalendar = Calendar.getInstance();
            selectedCalendar.set(year, month, dayOfMonth);

            int dayOfWeek = selectedCalendar.get(Calendar.DAY_OF_WEEK);
            if (dayOfWeek == Calendar.SATURDAY || dayOfWeek == Calendar.SUNDAY) {
                Toast.makeText(this, "Weekends are not available. Please select a weekday.", Toast.LENGTH_SHORT).show();
                calendarView.setDate(System.currentTimeMillis() - 1000, false, true); // Reset to current date
            } else {
                selectedDate = dayOfMonth + "/" + (month + 1) + "/" + year;
                showDialog();
            }
        });

        ImageView backButton = findViewById(R.id.back);
        backButton.setOnClickListener(v -> finish());

        Button cancelButton = findViewById(R.id.backToMap);
        cancelButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, meetup_location.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        });

        Button continueButton = findViewById(R.id.continueButton);
        continueButton.setOnClickListener(v -> {
            if (selectedDate == null || selectedTime == null) {
                Toast.makeText(this, "Please select both date and time", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(this, meetupDetails.class);
            intent.putExtra("date", selectedDate);
            intent.putExtra("time", selectedTime);
            intent.putExtra("location", location);
            intent.putExtra("totalQuantity", totalQuantity);
            intent.putExtra("totalPrice", totalPrice);
            startActivity(intent);
        });
    }

    private void showDialog() {
        time_dialog_box dialog = new time_dialog_box(this, time -> {
            selectedTime = time;
            Toast.makeText(this, "Selected: " + selectedDate + " at " + selectedTime, Toast.LENGTH_SHORT).show();
        });
        dialog.show();
    }
}
